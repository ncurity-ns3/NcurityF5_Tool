from __future__ import annotations

import getpass
from pathlib import Path

from pydantic import SecretStr
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from app.core.bigip_client import BigipClient
from app.core.f5os_client import F5osClient
from app.core.models import ConnectionProfile, DeviceTarget, PlatformKind
from app.gui.app_paths import local_data_dir
from app.gui.device_profile_store import DeviceProfileStore
from app.gui.session_manager import SessionManager
from app.gui.widgets.multi_device_entry import MODEL_ISERIES, MODEL_RSERIES, DeviceRowData
from app.gui.widgets.multi_device_table import MultiDeviceTablePanel
from app.gui.widgets.report_window import ReportWindow
from app.gui.workers.health_check_worker import HealthCheckWorker
from app.modules.health_check.findings import summarize_job_dir


class HealthCheckView(QWidget):
    def __init__(self, project_root: Path, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.project_root = project_root
        self.output_root = project_root / "output"
        self.data_dir = local_data_dir()
        self.profile_store = DeviceProfileStore(self.data_dir)
        self._worker: HealthCheckWorker | None = None
        self._last_report_html: Path | None = None
        self._last_run_device_count = 0
        self._build_ui()
        self._reload_saved_sessions()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        root = QVBoxLayout(content)

        title = QLabel("Health Check — 정기점검")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        root.addWidget(title)

        saved_box = QGroupBox("저장된 연결 (Session)")
        saved_form = QFormLayout(saved_box)
        row = QHBoxLayout()
        self.session_combo = QComboBox()
        self.session_combo.setMinimumWidth(280)
        self.load_session_btn = QPushButton("Load")
        self.save_session_btn = QPushButton("Save")
        self.delete_session_btn = QPushButton("Delete")
        row.addWidget(self.session_combo, stretch=1)
        row.addWidget(self.load_session_btn)
        row.addWidget(self.save_session_btn)
        row.addWidget(self.delete_session_btn)
        saved_form.addRow("프로필", row)
        self.add_from_saved_btn = QPushButton("+ Add from Saved (Multiple)")
        self.add_from_saved_btn.setVisible(False)
        saved_form.addRow("", self.add_from_saved_btn)
        root.addWidget(saved_box)

        mode_box = QGroupBox("Target Mode")
        mode_layout = QHBoxLayout(mode_box)
        self.single_radio = QRadioButton("Single")
        self.multiple_radio = QRadioButton("Multiple")
        self.single_radio.setChecked(True)
        mode_layout.addWidget(self.single_radio)
        mode_layout.addWidget(self.multiple_radio)
        self.single_radio.toggled.connect(self._on_target_mode_changed)
        self.multiple_radio.toggled.connect(self._on_target_mode_changed)
        root.addWidget(mode_box)

        self.single_group = QGroupBox("장비 연결 (Single)")
        single_form = QFormLayout(self.single_group)
        self.single_platform_combo = QComboBox()
        self.single_platform_combo.addItems([MODEL_ISERIES, MODEL_RSERIES])
        self.single_platform_combo.currentTextChanged.connect(self._on_single_platform_changed)
        self.label_edit = QLineEdit("lab-device-01")

        self.f5os_host_edit = QLineEdit()
        self.f5os_port_spin = QSpinBox()
        self.f5os_port_spin.setRange(1, 65535)
        self.f5os_port_spin.setValue(443)
        self.host_edit = QLineEdit()
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1, 65535)
        self.port_spin.setValue(443)
        self.f5os_host_label = QLabel("F5OS MGMT IP")
        self.f5os_port_label = QLabel("F5OS Port")

        single_form.addRow("장비 모델", self.single_platform_combo)
        single_form.addRow("장비 라벨", self.label_edit)
        single_form.addRow(self.f5os_host_label, self.f5os_host_edit)
        single_form.addRow(self.f5os_port_label, self.f5os_port_spin)
        single_form.addRow("TMOS MGMT IP", self.host_edit)
        single_form.addRow("TMOS Port", self.port_spin)
        root.addWidget(self.single_group)

        self.multi_group = QGroupBox("장비 목록 (Multiple)")
        multi_layout = QVBoxLayout(self.multi_group)
        auth_mode_row = QHBoxLayout()
        self.auth_common_radio = QRadioButton("공통 계정")
        self.auth_per_device_radio = QRadioButton("장비별 계정")
        self.auth_common_radio.setChecked(True)
        auth_mode_row.addWidget(self.auth_common_radio)
        auth_mode_row.addWidget(self.auth_per_device_radio)
        auth_mode_row.addStretch()
        multi_layout.addLayout(auth_mode_row)
        self.auth_common_radio.toggled.connect(self._on_multi_auth_mode_changed)
        self.auth_per_device_radio.toggled.connect(self._on_multi_auth_mode_changed)

        hint = QLabel(
            "장비당 2행 표 — Model/Label 병합, Stack: F5OS(위) → TMOS(아래). iSeries는 TMOS 1행만."
        )
        hint.setStyleSheet("color: #555;")
        hint.setWordWrap(True)
        multi_layout.addWidget(hint)

        self.device_table = MultiDeviceTablePanel()
        multi_layout.addWidget(self.device_table)
        row_btn = QHBoxLayout()
        self.add_row_btn = QPushButton("+ Add Device")
        self.remove_row_btn = QPushButton("Remove Selected")
        row_btn.addWidget(self.add_row_btn)
        row_btn.addWidget(self.remove_row_btn)
        row_btn.addStretch()
        multi_layout.addLayout(row_btn)
        self.multi_group.setVisible(False)
        root.addWidget(self.multi_group)

        self.auth_group = QGroupBox("인증 (공통)")
        auth_form = QFormLayout(self.auth_group)

        self.f5os_auth_box = QGroupBox("F5OS 인증 (공통)")
        f5os_auth_form = QFormLayout(self.f5os_auth_box)
        self.f5os_user_edit = QLineEdit("admin")
        self.f5os_pass_edit = QLineEdit()
        self.f5os_pass_edit.setEchoMode(QLineEdit.EchoMode.Password)
        f5os_auth_form.addRow("F5OS 사용자 ID", self.f5os_user_edit)
        f5os_auth_form.addRow("F5OS 비밀번호", self.f5os_pass_edit)
        auth_form.addRow(self.f5os_auth_box)

        self.user_edit = QLineEdit("admin")
        self.pass_edit = QLineEdit()
        self.pass_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.user_label = QLabel("TMOS 사용자 ID")
        self.pass_label = QLabel("TMOS 비밀번호")
        auth_form.addRow(self.user_label, self.user_edit)
        auth_form.addRow(self.pass_label, self.pass_edit)
        root.addWidget(self.auth_group)

        conn_btn = QHBoxLayout()
        self.test_btn = QPushButton("Test Connection")
        self.disconnect_btn = QPushButton("Disconnect")
        conn_btn.addWidget(self.test_btn)
        conn_btn.addWidget(self.disconnect_btn)
        conn_btn.addStretch()
        root.addLayout(conn_btn)

        self.session_label = QLabel("연결 상태: (없음)")
        self.session_label.setWordWrap(True)
        root.addWidget(self.session_label)

        meta_box = QGroupBox("점검 · 현장 정보")
        meta_form = QFormLayout(meta_box)
        self.site_edit = QLineEdit("lab-site")
        self.period_edit = QLineEdit()
        self.notes_edit = QLineEdit()
        self.chk_system = QCheckBox("system")
        self.chk_system.setChecked(True)
        self.chk_network = QCheckBox("network")
        self.chk_network.setChecked(True)
        self.chk_ltm = QCheckBox("ltm_summary")
        self.chk_ltm.setChecked(True)
        checks = QHBoxLayout()
        checks.addWidget(self.chk_system)
        checks.addWidget(self.chk_network)
        checks.addWidget(self.chk_ltm)
        meta_form.addRow("사이트명", self.site_edit)
        meta_form.addRow("점검 기간", self.period_edit)
        meta_form.addRow("비고", self.notes_edit)
        meta_form.addRow("항목", checks)
        root.addWidget(meta_box)

        run_row = QHBoxLayout()
        self.run_btn = QPushButton("Run Health Check")
        self.open_report_btn = QPushButton("Open Report Window")
        self.open_report_btn.setEnabled(False)
        self.open_folder_btn = QPushButton("Open Output Folder")
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.open_report_btn)
        run_row.addWidget(self.open_folder_btn)
        run_row.addStretch()
        root.addLayout(run_row)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        root.addWidget(self.progress)
        self.status_label = QLabel("Ready")
        root.addWidget(self.status_label)

        summary_box = QGroupBox("점검 결과 요약")
        summary_layout = QVBoxLayout(summary_box)
        self.summary_status = QLabel("—")
        self.summary_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.summary_status.setStyleSheet("font-size: 22px; font-weight: bold; padding: 8px;")
        self.summary_count = QLabel("Run Health Check 후 표시됩니다.")
        self.summary_count.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.summary_count.setWordWrap(True)
        self.summary_hint = QLabel("상세 내용은 Open Report Window에서 확인하세요.")
        self.summary_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.summary_hint.setStyleSheet("color: #555;")
        summary_layout.addWidget(self.summary_status)
        summary_layout.addWidget(self.summary_count)
        summary_layout.addWidget(self.summary_hint)
        root.addWidget(summary_box)

        self.test_btn.clicked.connect(self._test_connection)
        self.disconnect_btn.clicked.connect(self._disconnect)
        self.add_row_btn.clicked.connect(lambda: self._add_device_entry())
        self.remove_row_btn.clicked.connect(self._remove_device_entries)
        self.run_btn.clicked.connect(self._run_health_check)
        self.open_report_btn.clicked.connect(self._open_report_window)
        self.open_folder_btn.clicked.connect(self._open_output_folder)
        self.load_session_btn.clicked.connect(self._load_saved_session)
        self.save_session_btn.clicked.connect(self._save_current_session)
        self.delete_session_btn.clicked.connect(self._delete_saved_session)
        self.add_from_saved_btn.clicked.connect(self._add_row_from_saved)
        self.host_edit.textChanged.connect(self._refresh_session_label)
        self.port_spin.valueChanged.connect(self._refresh_session_label)

        self._on_single_platform_changed()
        self.device_table.add_device(DeviceRowData(model=MODEL_ISERIES, label="device-02"))

    @staticmethod
    def _platform_from_label(label: str) -> PlatformKind:
        return PlatformKind.rseries if label == MODEL_RSERIES else PlatformKind.iseries

    @staticmethod
    def _label_from_platform(platform: PlatformKind) -> str:
        return MODEL_RSERIES if platform == PlatformKind.rseries else MODEL_ISERIES

    def _single_platform(self) -> PlatformKind:
        return self._platform_from_label(self.single_platform_combo.currentText())

    def _needs_f5os_auth(self) -> bool:
        if self.single_radio.isChecked():
            return self._single_platform() == PlatformKind.rseries
        return self.device_table.any_rseries()

    def _clear_common_auth_fields(self) -> None:
        self.user_edit.clear()
        self.pass_edit.clear()
        self.f5os_user_edit.clear()
        self.f5os_pass_edit.clear()

    def _restore_common_auth_defaults(self) -> None:
        if not self.user_edit.text().strip():
            self.user_edit.setText("admin")
        if not self.f5os_user_edit.text().strip():
            self.f5os_user_edit.setText("admin")

    def _refresh_common_auth_panel(self) -> None:
        """Multiple+장비별: hide and clear 공통 인증. 공통/Single: F5OS → TMOS order."""
        if self._is_per_device_auth():
            self.auth_group.setVisible(False)
            self._clear_common_auth_fields()
        else:
            self.auth_group.setVisible(True)
            self._restore_common_auth_defaults()
            self.f5os_auth_box.setVisible(self._needs_f5os_auth())

        if self.single_radio.isChecked():
            rseries = self._single_platform() == PlatformKind.rseries
            self.f5os_host_label.setVisible(rseries)
            self.f5os_host_edit.setVisible(rseries)
            self.f5os_port_label.setVisible(rseries)
            self.f5os_port_spin.setVisible(rseries)

    def _on_single_platform_changed(self) -> None:
        self._refresh_common_auth_panel()
        self._refresh_session_label()

    def _is_per_device_auth(self) -> bool:
        return self.multiple_radio.isChecked() and self.auth_per_device_radio.isChecked()

    def _on_target_mode_changed(self) -> None:
        multiple = self.multiple_radio.isChecked()
        self.single_group.setVisible(not multiple)
        self.multi_group.setVisible(multiple)
        self.add_from_saved_btn.setVisible(multiple)
        if multiple:
            self._on_multi_auth_mode_changed()
        else:
            self._refresh_common_auth_panel()
            self._on_single_platform_changed()
        self._refresh_session_label()

    def _on_multi_auth_mode_changed(self) -> None:
        if not self.multiple_radio.isChecked():
            return
        per_device = self._is_per_device_auth()
        rows = self.device_table.snapshot()
        self.device_table.set_per_device_auth(per_device)
        if not rows:
            self.device_table.add_device()
        self._refresh_common_auth_panel()
        self._refresh_session_label()

    def _add_device_entry(self, data: DeviceRowData | None = None) -> None:
        self.device_table.add_device(data)
        self._refresh_common_auth_panel()

    def _remove_device_entries(self) -> None:
        if not self.device_table.remove_selected_device():
            QMessageBox.information(
                self,
                "Remove",
                "삭제할 장비 행을 선택한 뒤 Remove Selected를 누르세요.",
            )
        self._refresh_common_auth_panel()

    def _device_target(
        self,
        *,
        label: str,
        platform: PlatformKind,
        host: str,
        port: int,
        f5os_host: str,
        f5os_port: int,
    ) -> DeviceTarget:
        return DeviceTarget(
            label=label,
            platform=platform,
            host=host,
            port=port,
            f5os_host=f5os_host if platform == PlatformKind.rseries else "",
            f5os_port=f5os_port,
            verify_tls=False,
        )

    def _target_from_data(self, data: DeviceRowData) -> DeviceTarget | None:
        platform = (
            PlatformKind.rseries if data.model == MODEL_RSERIES else PlatformKind.iseries
        )
        if platform == PlatformKind.iseries and not data.tmos_host:
            return None
        if platform == PlatformKind.rseries and not data.tmos_host and not data.f5os_host:
            return None
        return self._device_target(
            label=data.label,
            platform=platform,
            host=data.tmos_host,
            port=data.tmos_port,
            f5os_host=data.f5os_host,
            f5os_port=data.f5os_port,
        )

    def _credentials_from_data(self, data: DeviceRowData) -> tuple[str, str]:
        if self._is_per_device_auth():
            return data.tmos_user, data.tmos_pass
        return self.user_edit.text().strip() or "admin", self.pass_edit.text()

    def _f5os_credentials_from_data(self, data: DeviceRowData) -> tuple[str, str]:
        if self._is_per_device_auth():
            return data.f5os_user, data.f5os_pass
        return self.f5os_user_edit.text().strip() or "admin", self.f5os_pass_edit.text()

    def _refresh_session_label(self) -> None:
        if self.multiple_radio.isChecked():
            i_cnt = r_cnt = 0
            for data in self.device_table.snapshot():
                if data.model == MODEL_RSERIES:
                    r_cnt += 1
                else:
                    i_cnt += 1
            mode = "장비별" if self._is_per_device_auth() else "공통"
            self.session_label.setText(
                f"연결 상태: Multiple — iSeries {i_cnt}대, rSeries {r_cnt}대, 인증={mode}"
            )
            return
        parts: list[str] = []
        host = self.host_edit.text().strip()
        port = self.port_spin.value()
        tmos = SessionManager.instance().status_text(host, port, scope="tmos")
        if tmos:
            parts.append(tmos)
        if self._single_platform() == PlatformKind.rseries:
            fh = self.f5os_host_edit.text().strip()
            fp = self.f5os_port_spin.value()
            f5os = SessionManager.instance().status_text(fh, fp, scope="f5os")
            if f5os:
                parts.append(f5os)
        self.session_label.setText(
            "연결 상태: " + (" | ".join(parts) if parts else "(없음)")
        )

    def _set_connection_status(self, ok: bool, message: str) -> None:
        color = "#1a7f37" if ok else "#b42318"
        self.session_label.setText(f'<span style="color:{color}">{message}</span>')
        self.session_label.setTextFormat(Qt.TextFormat.RichText)
        self.status_label.setText(message)

    def _test_tmos(self, host: str, port: int, user: str, password: str) -> tuple[bool, str]:
        profile = ConnectionProfile(
            target=self._device_target(
                label="test",
                platform=PlatformKind.iseries,
                host=host,
                port=port,
                f5os_host="",
                f5os_port=443,
            ),
            username=user,
            password=SecretStr(password),
        )
        client = BigipClient(profile)
        client.authenticate()
        info = client.get_system_info()
        hostname = str(info.get("hostname", info.get("version", "ok")))
        SessionManager.instance().set(host, port, user, "live-session", scope="tmos")
        return True, hostname

    def _test_f5os(self, host: str, port: int, user: str, password: str) -> tuple[bool, str]:
        client = F5osClient(host, port, user, password, verify_tls=False)
        overview = client.get_system_overview()
        SessionManager.instance().set(host, port, user, "live-session", scope="f5os")
        return True, str(overview.get("product", overview.get("hostname", "ok")))[:80]

    def _test_connection(self) -> None:
        lines: list[str] = []
        ok_all = True
        try:
            if self.single_radio.isChecked():
                platform = self._single_platform()
                tmos_user = self.user_edit.text().strip() or "admin"
                tmos_pass = self.pass_edit.text()
                if platform == PlatformKind.rseries:
                    fh = self.f5os_host_edit.text().strip()
                    if not fh:
                        QMessageBox.warning(self, "Test Connection", "F5OS MGMT IP를 입력하세요.")
                        return
                    fu = self.f5os_user_edit.text().strip() or "admin"
                    fp = self.f5os_pass_edit.text()
                    if not fp:
                        QMessageBox.warning(self, "Test Connection", "F5OS 비밀번호를 입력하세요.")
                        return
                    ok, detail = self._test_f5os(fh, self.f5os_port_spin.value(), fu, fp)
                    lines.append(f"F5OS {fh}: {'OK' if ok else 'FAIL'} — {detail}")
                    ok_all = ok_all and ok
                if platform == PlatformKind.iseries or self.host_edit.text().strip():
                    host = self.host_edit.text().strip()
                    if not host and platform == PlatformKind.iseries:
                        QMessageBox.warning(self, "Test Connection", "TMOS MGMT IP를 입력하세요.")
                        return
                    if host:
                        if not tmos_pass:
                            QMessageBox.warning(self, "Test Connection", "TMOS 비밀번호를 입력하세요.")
                            return
                        ok, detail = self._test_tmos(host, self.port_spin.value(), tmos_user, tmos_pass)
                        lines.append(f"TMOS {host}: {'OK' if ok else 'FAIL'} — {detail}")
                        ok_all = ok_all and ok
            else:
                devices = self.device_table.snapshot()
                if not devices:
                    QMessageBox.warning(self, "Test Connection", "장비 목록이 비어 있습니다.")
                    return
                for idx, data in enumerate(devices):
                    label = data.label.strip() or f"device-{idx + 1}"
                    platform = (
                        PlatformKind.rseries
                        if data.model == MODEL_RSERIES
                        else PlatformKind.iseries
                    )
                    lines.append(f"── [{label}] ──")
                    tmos_user, tmos_pass = self._credentials_from_data(data)
                    if platform == PlatformKind.rseries:
                        if not data.f5os_host:
                            lines.append(f"[{label}] F5OS: SKIP (MGMT IP 없음)")
                            ok_all = False
                        elif not self._f5os_credentials_from_data(data)[1]:
                            lines.append(f"[{label}] F5OS: SKIP (비밀번호 없음)")
                            ok_all = False
                        else:
                            fu, fpw = self._f5os_credentials_from_data(data)
                            try:
                                ok, detail = self._test_f5os(
                                    data.f5os_host, data.f5os_port, fu, fpw
                                )
                                lines.append(
                                    f"[{label}] F5OS {data.f5os_host}: "
                                    f"{'OK' if ok else 'FAIL'} — {detail}"
                                )
                                ok_all = ok_all and ok
                            except Exception as exc:  # noqa: BLE001
                                ok_all = False
                                lines.append(f"[{label}] F5OS FAIL — {exc}")
                    if platform == PlatformKind.iseries or data.tmos_host:
                        if not data.tmos_host:
                            lines.append(f"[{label}] TMOS: SKIP (MGMT IP 없음)")
                            ok_all = False
                        elif not tmos_pass:
                            lines.append(f"[{label}] TMOS: SKIP (비밀번호 없음)")
                            ok_all = False
                        else:
                            try:
                                ok, detail = self._test_tmos(
                                    data.tmos_host, data.tmos_port, tmos_user, tmos_pass
                                )
                                lines.append(
                                    f"[{label}] TMOS {data.tmos_host}: "
                                    f"{'OK' if ok else 'FAIL'} — {detail}"
                                )
                                ok_all = ok_all and ok
                            except Exception as exc:  # noqa: BLE001
                                ok_all = False
                                lines.append(f"[{label}] TMOS FAIL — {exc}")
        except Exception as exc:  # noqa: BLE001
            ok_all = False
            lines.append(str(exc).split("\n")[0][:200])

        title = "Test Connection — Success" if ok_all else "Test Connection — Failed"
        if self.multiple_radio.isChecked():
            n = len(self.device_table.snapshot())
            msg = f"연결 테스트 — {n}대" + (" (전체 성공)" if ok_all else " (일부 실패)")
        else:
            msg = "연결 성공" if ok_all else "연결 실패"
        self._set_connection_status(ok_all, msg)
        (QMessageBox.information if ok_all else QMessageBox.warning)(self, title, "\n".join(lines))

    def _disconnect(self) -> None:
        SessionManager.instance().clear_all()
        self.session_label.setText("연결 상태: 세션 삭제됨")
        self.status_label.setText("Disconnected")

    def _connection_from_data(
        self, target: DeviceTarget, data: DeviceRowData
    ) -> ConnectionProfile:
        user, password = self._credentials_from_data(data)
        if not password and target.host.strip():
            raise ValueError(f"{target.label}: TMOS 비밀번호가 필요합니다.")
        f5os_user, f5os_pass = None, None
        if target.platform == PlatformKind.rseries and target.f5os_host.strip():
            f5os_user, f5os_pass = self._f5os_credentials_from_data(data)
            if not f5os_pass:
                raise ValueError(f"{target.label}: F5OS 비밀번호가 필요합니다.")
        return ConnectionProfile(
            target=target,
            username=user,
            password=SecretStr(password or " "),
            f5os_username=f5os_user,
            f5os_password=SecretStr(f5os_pass) if f5os_pass else None,
        )

    def _collect_targets_and_connections(
        self,
    ) -> tuple[list[DeviceTarget], list[ConnectionProfile]]:
        if self.single_radio.isChecked():
            platform = self._single_platform()
            target = self._device_target(
                label=self.label_edit.text().strip() or "device",
                platform=platform,
                host=self.host_edit.text().strip(),
                port=self.port_spin.value(),
                f5os_host=self.f5os_host_edit.text().strip(),
                f5os_port=self.f5os_port_spin.value(),
            )
            data = DeviceRowData(
                model=self.single_platform_combo.currentText(),
                label=target.label,
                tmos_host=target.host,
                tmos_port=target.port,
                f5os_host=target.f5os_host,
                f5os_port=target.f5os_port,
                tmos_user=self.user_edit.text().strip() or "admin",
                tmos_pass=self.pass_edit.text(),
                f5os_user=self.f5os_user_edit.text().strip() or "admin",
                f5os_pass=self.f5os_pass_edit.text(),
            )
            return [target], [self._connection_from_data(target, data)]

        targets: list[DeviceTarget] = []
        connections: list[ConnectionProfile] = []
        for data in self.device_table.snapshot():
            target = self._target_from_data(data)
            if target is None:
                continue
            targets.append(target)
            connections.append(self._connection_from_data(target, data))
        return targets, connections

    def _categories(self) -> list[str]:
        cats: list[str] = []
        if self.chk_system.isChecked():
            cats.append("system")
        if self.chk_network.isChecked():
            cats.append("network")
        if self.chk_ltm.isChecked():
            cats.append("ltm_summary")
        return cats or ["system"]

    def _reload_saved_sessions(self) -> None:
        current = self.session_combo.currentData()
        self.session_combo.clear()
        self.session_combo.addItem("(선택 없음)", None)
        for profile in self.profile_store.list_profiles():
            kind = "rSeries" if profile.platform == PlatformKind.rseries else "iSeries"
            text = f"[{kind}] {profile.label}"
            if profile.platform == PlatformKind.rseries and profile.f5os_host:
                text += f" — F5OS {profile.f5os_host}:{profile.f5os_port}"
            if profile.host:
                text += f" | TMOS {profile.host}:{profile.port}"
            self.session_combo.addItem(text, profile.profile_id)
        if current:
            idx = self.session_combo.findData(current)
            if idx >= 0:
                self.session_combo.setCurrentIndex(idx)

    def _profile_to_row(self, profile) -> DeviceRowData:
        return DeviceRowData(
            model=self._label_from_platform(profile.platform),
            label=profile.label,
            f5os_host=profile.f5os_host,
            f5os_port=profile.f5os_port,
            tmos_host=profile.host,
            tmos_port=profile.port,
            tmos_user=profile.username,
            f5os_user=profile.f5os_username or profile.username,
        )

    def _load_saved_session(self) -> None:
        profile_id = self.session_combo.currentData()
        if not profile_id:
            QMessageBox.information(self, "Load Session", "불러올 프로필을 선택하세요.")
            return
        profile = self.profile_store.get(profile_id)
        if profile is None:
            QMessageBox.warning(self, "Load Session", "프로필을 찾을 수 없습니다.")
            self._reload_saved_sessions()
            return
        row = self._profile_to_row(profile)
        if self.single_radio.isChecked():
            self.single_platform_combo.setCurrentText(row.model)
            self.label_edit.setText(row.label)
            self.f5os_host_edit.setText(row.f5os_host)
            self.f5os_port_spin.setValue(row.f5os_port)
            self.host_edit.setText(row.tmos_host)
            self.port_spin.setValue(row.tmos_port)
            self.user_edit.setText(row.tmos_user)
            self.f5os_user_edit.setText(row.f5os_user)
        else:
            self._add_device_entry(row)
        self._refresh_common_auth_panel()
        self._refresh_session_label()

    def _save_current_session(self) -> None:
        if self.single_radio.isChecked():
            platform = self._single_platform()
            label = self.label_edit.text().strip()
            host = self.host_edit.text().strip()
            port = self.port_spin.value()
            user = self.user_edit.text().strip() or "admin"
            f5os_host = self.f5os_host_edit.text().strip()
            f5os_port = self.f5os_port_spin.value()
            f5os_user = self.f5os_user_edit.text().strip() or user
        else:
            idx = self.device_table.selected_device_index()
            devices = self.device_table.snapshot()
            if idx < 0 or idx >= len(devices):
                QMessageBox.warning(self, "Save Session", "저장할 장비 행을 선택하세요.")
                return
            data = devices[idx]
            platform = self.device_table.platform_at(idx)
            label, host, port = data.label, data.tmos_host, data.tmos_port
            user = data.tmos_user
            f5os_host, f5os_port = data.f5os_host, data.f5os_port
            f5os_user = data.f5os_user
        if platform == PlatformKind.iseries and not host:
            QMessageBox.warning(self, "Save Session", "TMOS MGMT IP가 필요합니다.")
            return
        if platform == PlatformKind.rseries and not f5os_host and not host:
            QMessageBox.warning(self, "Save Session", "rSeries는 F5OS 또는 TMOS MGMT IP가 필요합니다.")
            return
        self.profile_store.save(
            label=label,
            platform=platform,
            host=host,
            port=port,
            username=user,
            f5os_host=f5os_host,
            f5os_port=f5os_port,
            f5os_username=f5os_user,
        )
        self._reload_saved_sessions()
        QMessageBox.information(self, "Save Session", "저장됨 (비밀번호는 저장하지 않음)")

    def _delete_saved_session(self) -> None:
        profile_id = self.session_combo.currentData()
        if not profile_id:
            QMessageBox.information(self, "Delete Session", "삭제할 프로필을 선택하세요.")
            return
        self.profile_store.delete(profile_id)
        self._reload_saved_sessions()

    def _add_row_from_saved(self) -> None:
        self.multiple_radio.setChecked(True)
        self._load_saved_session()

    def _update_summary_panel(self, job_dir: Path) -> None:
        import json

        healthy, count, _ = summarize_job_dir(job_dir)
        device_n = self._last_run_device_count
        raw_path = job_dir / "raw_collection.json"
        if raw_path.is_file():
            try:
                device_n = len(json.loads(raw_path.read_text(encoding="utf-8")))
            except json.JSONDecodeError:
                pass
        if healthy:
            self.summary_status.setText("Healthy")
            self.summary_status.setStyleSheet(
                "font-size: 22px; font-weight: bold; color: #1a7f37; padding: 8px;"
            )
            self.summary_count.setText(f"점검 장비: {device_n}대 · Unhealthy 사유: 0건")
        else:
            self.summary_status.setText("Unhealthy")
            self.summary_status.setStyleSheet(
                "font-size: 22px; font-weight: bold; color: #b42318; padding: 8px;"
            )
            self.summary_count.setText(
                f"점검 장비: {device_n}대 · Unhealthy 사유: {count}건"
            )

    def _run_health_check(self) -> None:
        try:
            targets, connections = self._collect_targets_and_connections()
        except ValueError as exc:
            QMessageBox.warning(self, "Run", str(exc))
            return
        if not targets:
            QMessageBox.warning(self, "Run", "대상 장비가 없습니다.")
            return
        for t in targets:
            if t.platform == PlatformKind.rseries and not t.f5os_host.strip() and not t.host.strip():
                QMessageBox.warning(
                    self, "Run", f"{t.label}: rSeries는 F5OS 또는 TMOS MGMT IP가 필요합니다."
                )
                return

        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.run_btn.setEnabled(False)
        self.status_label.setText("Running…")

        self._last_run_device_count = len(targets)
        self._worker = HealthCheckWorker(
            project_root=self.project_root,
            output_root=self.output_root,
            data_dir=self.data_dir,
            site_name=self.site_edit.text(),
            period=self.period_edit.text(),
            notes=self.notes_edit.text(),
            targets=targets,
            categories=self._categories(),
            connections=connections,
            mock_fixtures=None,
            operator=getpass.getuser(),
        )
        self._worker.finished_ok.connect(self._on_job_ok)
        self._worker.failed.connect(self._on_job_fail)
        self._worker.start()

    def _on_job_ok(self, job: object, out_dir: str) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        job_dir = Path(out_dir)
        self.status_label.setText(
            f"Completed — {self._last_run_device_count} device(s), "
            f"Job {getattr(job, 'job_id', '')}"
        )
        html = job_dir / "report.html"
        self._last_report_html = html if html.is_file() else None
        self.open_report_btn.setEnabled(self._last_report_html is not None)
        self._update_summary_panel(job_dir)

    def _on_job_fail(self, message: str) -> None:
        self.progress.setVisible(False)
        self.run_btn.setEnabled(True)
        self.status_label.setText("Failed")
        self.summary_status.setText("Unhealthy")
        self.summary_status.setStyleSheet(
            "font-size: 22px; font-weight: bold; color: #b42318; padding: 8px;"
        )
        self.summary_count.setText("Unhealthy 사유: (job failed)")
        QMessageBox.critical(self, "Run Health Check", message)

    def _open_report_window(self) -> None:
        if self._last_report_html and self._last_report_html.is_file():
            ReportWindow(self._last_report_html, self).exec()
        else:
            QMessageBox.information(self, "Report", "먼저 Run Health Check를 실행하세요.")

    def _open_output_folder(self) -> None:
        import os

        self.output_root.mkdir(parents=True, exist_ok=True)
        os.startfile(self.output_root)  # noqa: S606
