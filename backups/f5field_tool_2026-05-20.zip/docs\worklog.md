# worklog

---

## 2026-05-20 — gui / ux 설계 문서 작성

### 작업 내용

- 사용자 피드백: mgmt ip, id/pw 입력 gui부터 기대 — **구현 전 설계 우선**
- 신규 문서:
  - `docs/gui_design.md` — 화면 구조, 장비 연결 폼, 모듈 wizard, 보안 ux, 구현 순서
  - `docs/ui_flows.md` — mermaid 흐름, connection 화면 ascii wireframe
  - `docs/gui_field_catalog.md` — ui 필드 ↔ pydantic/backend 매핑表
- `docs/spec.md`, `readme.md` 에 gui 문서 링크 추가

### 현재 코드와의 관계

- cli + 모듈 = 엔진 검증 완료 (11 pytest pass, health-check fixture 성공)
- gui = **설계만 완료**, 코딩 대기 (설계 §16 open questions 확인 후)

### 설계 피드백 반영 (2026-05-20)

| 항목 | 결정 |
|------|------|
| 계정 | mgmt ip별 **세션 유지**(토큰 메모리), **username 프로필 저장** |
| 장비 | **Single / Multiple** — Multiple = 1 job N대 순차 |
| 리포트 | **QWebEngineView 인앱** |
| 언어 | **메뉴·버튼 EN** / **라벨·안내 KO** |
| 플랫폼 | phase 1 **TMOS만 표시** (gray 항목 없음) |

문서: `gui_design.md` v0.2, `ui_flows.md`, `gui_field_catalog.md` v0.2

### 다음 작업

1. live icontrol Test Connection (preview는 세션만 등록)
2. initial_setup / vpe_macro gui wizard
3. devices profile 저장 (username)

---

## 2026-05-20 — multiple 모드 공통 인증 ui (사용자 피드백)

### 피드백
- Multiple 선택 시 계정(ID/PW) 입력란이 보이지 않음

### 수정 (다음 실행부터)
- `health_check_view.py`: **공통 인증 (모든 장비)** 그룹 분리 — Single/Multiple 모두 표시
- Multiple 시 장비 테이블 + 공통 ID/PW/TLS/Fixture

---

## 2026-05-20 — gui preview 검증 완료 (사용자)

- `scripts\run_gui.cmd`: 경로 `&` 수정 후 정상, **Report Preview 팝업 없음**
- WebEngine import 순서 수정 적용됨
- 다음: Health Check 실제 화면 사용·live icontrol 연동, initial_setup/vpe gui

---

## 2026-05-20 — webengine import order fix

### 증상
`QtWebEngineWidgets must be imported ... before QCoreApplication is created`

### 수정
- `bootstrap_webengine_before_qapplication()` — WebEngine import + AA_ShareOpenGLContexts **후** `QApplication()`
- `app/gui/main.py` import 순서 정리

---

## 2026-05-20 — webengine dll path (windows)

### 작업
- `app/gui/qt_utils.py`: `os.add_dll_directory(Qt6/bin)` for WebEngine on Windows
- `scripts/check_webengine.py` / `check_webengine.cmd` 진단용
- startup popup에 실패 상세 메시지 포함

### 사용자 확인
```cmd
scripts\check_webengine.cmd
```

---

## 2026-05-20 — cmd `&` 경로 버그 수정

### 증상

- `Config & Rules & Apps` 경로에서 `echo project: %CD%` 시 `Rules` 가 별도 명령으로 실행됨
- PyQt6-WebEngine 설치 후에도 Report Preview 안내 팝업

### 수정

- `run_gui.cmd` / `setup_dev.cmd` / `run_tests.cmd`: `pushd "%~dp0.."`, `echo "%CD%"`, python 경로 따옴표
- `scripts/run_gui.ps1` 추가 (& 경로 안전)
- `report_viewer.py`: QApplication 후 lazy WebEngine 로드

---

## 2026-05-20 — gui preview (대략적인 화면)

### 작업 내용

- `app/gui/` — PyQt6 main window, nav(영문), Health Check 화면(한글 라벨)
- Single / Multiple, device table, Fixture Mode, Run → embedded report
- `SessionManager` 메모리 세션 (Test Connection 미리보기)
- `scripts/run_gui.cmd`, `python -m app.gui.main`, `f5tool-gui` entry

### 실행

```cmd
scripts\run_gui.cmd
```

### 한계 (preview)

- Test Connection: 실제 BIG-IP 미연동, 세션 등록만
- Initial Setup / VPE Macro / Reports: placeholder

---

## 2026-05-20 — run_tests: py -3.12 오류 수정

### 증상

- `setup_dev.cmd` 성공 (`.venv` + pip 설치 완료, python 3.14)
- `run_tests.cmd` 실패: `py.exe : [ERROR] No runtime installed that matches 3.12`

### 원인

- `find_python.ps1` 이 `.venv` 검증 전에 `py -3.12` 호출
- `$ErrorActionPreference = Stop` 환경에서 py 런처 stderr가 terminating error 로 처리됨

### 수정

- `run_tests.ps1`: `.venv\Scripts\python.exe` 있으면 **즉시 사용** (find_python 생략)
- `find_python.ps1`: venv 우선, py 프로브는 `SilentlyContinue` + `-3.14` 등 포함
- `setup_dev.ps1`: venv 생성 시 `py -3` / `py -3.14` 폴백, pip exit code 검사

### 테스트 결과 (2026-05-20 사용자 실행)

- `scripts\run_tests.cmd` **성공**
- python: `.venv\Scripts\python.exe` — **Python 3.14.5**
- naming convention: ok
- pytest: **11 passed in 1.66s**
  - integration: `test_health_check_job`
  - naming: 5 tests
  - unit: safety_gate, redaction, initial_setup, vpe_macro, bigip_client write block

### 다음 작업

1. ` .venv\Scripts\python.exe -m app.main health-check --use-fixture --output output`
2. phase 1 gui (pyqt6)
3. pyinstaller 오프라인 번들

---

## 2026-05-20 — milestone backup + multiple test/run fixes

### 작업 내용

- Multiple Test Connection / Run: **목록 전체** 처리, `[label]` 표시, connection **순서(index)** 매칭
- Add Device: Port 기본 **443**, 라벨 `device-N` 자동
- 백업: `backups/f5field_tool_2026-05-20.zip`, `docs/milestone_backup_2026-05-20.md`

### 다음

- 정기점검 리스트 (점검 항목·체크리스트)

---

## 2026-05-20 — iSeries / rSeries platform in health check gui

### 작업 내용

- **장비 모델:** `iSeries (TMOS)` / `rSeries (F5OS+TMOS)` — Single·Multiple 테이블 Model 열
- **rSeries 전용:** F5OS MGMT IP/Port + F5OS 인증 (공통·장비별), TMOS tenant MGMT는 선택
- **수집:** `platform_router` → `TmosCollector` / `RseriesCollector` + `F5osClient`
- **저장 프로필:** platform, f5os_host/port/username 포함 (비밀번호 미저장)
- **Test Connection:** TMOS·F5OS 각각 성공/실패 표시

---

## 2026-05-20 — health check gui ux round 2 (sessions, summary, no flicker)

### 작업 내용

- **저장된 연결:** `%LOCALAPPDATA%\f5tool\devices\*.json` — label/host/port/username (비밀번호 미저장), Load/Save/Delete, Multiple 시 Add from Saved
- **TLS 검증 / Fixture Mode:** GUI에서 제거, MGMT는 `verify_tls=False` 고정
- **Run 후 깜빡임:** Run 시 WebEngine 미리보기 제거 — 요약 패널만 갱신, HTML은 Open Report Window에서만
- **요약:** Healthy / Unhealthy + `Unhealthy 사유: N건` (`app/modules/health_check/findings.py`)
- **실제 수집:** Run 시 `ConnectionProfile` 전달 (Test Connection과 동일 계정)

---

## 2026-05-20 — health check gui ux (multiple auth, test connection, report window)

### 작업 내용

- **Multiple 인증:** `공통 계정` / `장비별 계정` 라디오 — 장비별 선택 시 테이블에 User ID·Password 열 추가, 공통 ID/PW 필드 숨김
- **Test Connection:** Fixture 제외 시 실제 `BigipClient.authenticate()` + system info — 성공/실패 제목·메시지·연결 상태 라벨(녹색/빨강) 구분
- **Report:** `Open Report Window` — 별도 대화상자(`ReportWindow`)에서 전체 HTML; 미리보기 영역은 요약용
- **HTML 리포트 템플릿:** 스타일·categories·status 컬럼 보강 (`templates/health_check_report.html.j2`)
- **Initial Setup:** 메뉴 placeholder 유지 — 다음 구현 예정

### 테스트

- pytest 11 passed (새 경로 venv)

---

## 2026-05-20 — project root relocated

### 작업 내용

- 프로젝트 루트를 사용자 지정 경로로 이동:
  - `C:\Users\ejes3\Ejes_OneDrive\OneDrive - Ncurity\바탕 화면\WorksFiles\F5 Project\Config & Rules & Apps\AI First`
- cursor agent workspace를 위 경로로 전환 (`move_agent_to_root`)
- `C:\Users\ejes3` 에 있던 poc 코드·테스트·스크립트를 새 경로에 재구성
- `docs/windows_setup.md`, `readme.md` 경로 안내 갱신
- 이전 위치(`C:\Users\ejes3`)는 legacy — **새 작업은 ai first 폴더만 사용**

### 테스트 결과

- (사용자 pc) `scripts\setup_dev.cmd` → `scripts\run_tests.cmd` 실행 필요

### 다음 작업

1. 새 경로에서 venv 생성 및 pytest
2. phase 1 gui / pyinstaller

---

## 2026-05-20 — windows python/pip 미설치 대응

(이전 루트 `C:\Users\ejes3` 에서 수행 — 내용 동일, 스크립트는 새 경로에 포함됨)

---

## 2026-05-20 — naming + phase 1 poc bootstrap

설계 문서: `docs/spec.md`, `docs/roadmap.md`, `docs/security_rules.md`, `docs/test_plan.md`
