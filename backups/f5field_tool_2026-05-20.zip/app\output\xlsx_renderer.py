from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook

from app.core.models import ReportContext


def render_xlsx_report(context: ReportContext, output_path: Path) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "summary"
    ws.append(["job_id", context.job_id])
    ws.append(["site", context.site_name])
    ws.append(["devices", len(context.devices)])
    dev = wb.create_sheet("devices")
    dev.append(["label", "host", "categories"])
    for d in context.devices:
        dev.append([d.device_label, d.host, ", ".join(d.data.keys())])
    wb.save(output_path)
