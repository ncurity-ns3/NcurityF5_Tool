from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from app.core.models import ReportContext

_TEMPLATE_DIR = Path(__file__).resolve().parents[2] / "templates"


def render_html_report(context: ReportContext, output_path: Path) -> None:
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    template = env.get_template("health_check_report.html.j2")
    html = template.render(
        job_id=context.job_id,
        site_name=context.site_name,
        period=context.period,
        engineer_notes=context.engineer_notes,
        devices=context.devices,
        exceptions=context.exceptions,
    )
    output_path.write_text(html, encoding="utf-8")
