from __future__ import annotations

from typing import Any

from app.adapters.base import MockableAdapter
from app.core.bigip_client import BigipClient
from app.core.models import ConnectionProfile, DeviceTarget, HealthCheckProfile


class TmosCollector(MockableAdapter):
    def __init__(
        self,
        target: DeviceTarget,
        *,
        connection: ConnectionProfile | None = None,
        mock_responses: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(connection)
        self.target = target
        self.mock_responses = mock_responses

    def collect(self, profile: HealthCheckProfile):
        label = self.target.label
        host = self.target.host
        sections: dict[str, Any] = {}
        errors: list[str] = []

        if self.mock_responses is not None:
            for category in profile.categories:
                if category in self.mock_responses:
                    sections[category] = self.mock_responses[category]
                else:
                    errors.append(f"missing mock for category: {category}")
            return self._merge_sections(label, host, sections, errors)

        assert self.connection is not None
        client = BigipClient(self.connection)
        client.authenticate()

        def collect_network() -> dict[str, Any]:
            return {
                "vlans": client.get_vlan_summary(),
                "self_ips": client.get_self_ip_summary(),
                "routes": client.get_route_summary(),
            }

        collectors = {
            "system": client.get_system_info,
            "network": collect_network,
            "ltm_summary": client.get_pool_summary,
            "failover": client.get_failover_state,
        }

        for category in profile.categories:
            fn = collectors.get(category)
            if fn is None:
                errors.append(f"unsupported category: {category}")
                continue
            try:
                sections[category] = fn()
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{category}: {exc}")

        return self._merge_sections(label, host, sections, errors)
