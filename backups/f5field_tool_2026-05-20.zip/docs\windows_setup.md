# windows setup guide

## project root

```cmd
cd /d "C:\Users\ejes3\Ejes_OneDrive\OneDrive - Ncurity\바탕 화면\WorksFiles\F5 Project\Config & Rules & Apps\AI First"
```

## symptom

- `pip` is not recognized
- `python` prints only `Python` (microsoft store stub)

## fix

1. install python 3.12+ from https://www.python.org/downloads/windows/ (add to path + pip)
2. disable app execution aliases for `python.exe` and `python3.exe`
3. open a **new** terminal

## setup (use cmd wrappers)

```cmd
cd /d "C:\Users\ejes3\Ejes_OneDrive\OneDrive - Ncurity\바탕 화면\WorksFiles\F5 Project\Config & Rules & Apps\AI First"
scripts\setup_dev.cmd
scripts\run_tests.cmd
```

do **not** rely on bare `pip` or `python` until venv exists. use:

```cmd
.venv\Scripts\python.exe -m pip install -r requirements_dev.txt
.venv\Scripts\python.exe -m pytest tests -v
.venv\Scripts\python.exe -m app.main health-check --use-fixture --output output
```

## verify

```cmd
py --version
where py
dir .venv\Scripts\python.exe
```
