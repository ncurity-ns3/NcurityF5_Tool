from __future__ import annotations

from typing import Any

import httpx

from app.core.redaction import redact_data


class F5osClient:
    """read-only f5os rest client (rseries platform mgmt) — subset for health check."""

    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        *,
        verify_tls: bool = False,
        timeout: float = 120.0,
    ) -> None:
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.verify_tls = verify_tls
        self.timeout = timeout

    def _base_url(self) -> str:
        return f"https://{self.host}:{self.port}"

    def get_system_overview(self) -> dict[str, Any]:
        """GET /api/v1/system/overview (basic auth) — common on rseries f5os."""
        url = f"{self._base_url()}/api/v1/system/overview"
        with httpx.Client(verify=self.verify_tls, timeout=self.timeout) as client:
            response = client.get(url, auth=(self.username, self.password))
            response.raise_for_status()
            return redact_data(response.json())

    def get_health(self) -> dict[str, Any]:
        url = f"{self._base_url()}/api/v1/system/health"
        with httpx.Client(verify=self.verify_tls, timeout=self.timeout) as client:
            response = client.get(url, auth=(self.username, self.password))
            response.raise_for_status()
            return redact_data(response.json())
