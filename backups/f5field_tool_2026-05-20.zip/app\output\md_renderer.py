from __future__ import annotations

from pathlib import Path

from app.core.models import ReportContext


def render_md_report(context: ReportContext, output_path: Path) -> None:
    lines = [f"# health check — {context.site_name}", "", f"job: `{context.job_id}`", ""]
    for device in context.devices:
        lines.append(f"## {device.device_label}")
        lines.append(f"- categories: {', '.join(device.data.keys())}")
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
