from __future__ import annotations

from typing import Any

import httpx

from app.core.models import ConnectionProfile, OperationClass
from app.core.redaction import redact_data
from app.core.safety_gate import SafetyGate


class BigipClient:
    """read-only icontrol rest client (subset) with safety gate on writes."""

    def __init__(
        self,
        profile: ConnectionProfile,
        *,
        safety_gate: SafetyGate | None = None,
        timeout: float = 120.0,
    ) -> None:
        self.profile = profile
        self.safety_gate = safety_gate or SafetyGate()
        self.timeout = timeout
        self._token: str | None = None

    def _base_url(self) -> str:
        target = self.profile.target
        return f"https://{target.host}:{target.port}/mgmt"

    def _auth_headers(self) -> dict[str, str]:
        if self._token:
            return {"x-f5-auth-token": self._token}
        return {}

    def authenticate(self) -> None:
        url = f"{self._base_url()}/shared/authn/login"
        payload = {
            "username": self.profile.username,
            "password": self.profile.password.get_secret_value(),
        }
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
            response = client.post(url, json=payload)
            response.raise_for_status()
            body = response.json()
            self._token = body.get("token", {}).get("token")

    def get(self, path: str) -> dict[str, Any]:
        if not path.startswith("/"):
            path = f"/{path}"
        url = f"{self._base_url()}{path}"
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
            response = client.get(url, headers=self._auth_headers())
            response.raise_for_status()
            return redact_data(response.json())

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        self.safety_gate.assert_allowed(OperationClass.wr)
        if not path.startswith("/"):
            path = f"/{path}"
        url = f"{self._base_url()}{path}"
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
            response = client.post(url, json=payload, headers=self._auth_headers())
            response.raise_for_status()
            return redact_data(response.json())

    def get_system_info(self) -> dict[str, Any]:
        return self.get("/tm/sys/global-settings")

    def get_failover_state(self) -> dict[str, Any]:
        try:
            return self.get("/tm/cm/failover-status")
        except httpx.HTTPError:
            return {"status": "unknown"}

    def get_vlan_summary(self) -> dict[str, Any]:
        return self.get("/tm/net/vlan")

    def get_self_ip_summary(self) -> dict[str, Any]:
        return self.get("/tm/net/self")

    def get_route_summary(self) -> dict[str, Any]:
        return self.get("/tm/net/route")

    def get_pool_summary(self) -> dict[str, Any]:
        return self.get("/tm/ltm/pool")
