from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QComboBox,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.gui.app_paths import local_data_dir
from app.gui.theme import (
    mark_page_subtitle,
    mark_page_title,
    mark_primary_button,
    mark_secondary_button,
    mark_step_card,
)
from app.gui.folder_utils import module_output_root, open_in_file_manager
from app.modules.os_upgrade.k7727_versions import load_k7727_versions
from app.gui.widgets.device_connection_panel import DeviceConnectionPanel
from app.gui.form_controls import configure_form_combobox
from app.gui.widgets.ncurity_checkbox import NcurityCheckBox
from app.gui.widgets.report_window import ReportWindow
from app.gui.workers.device_overview_worker import DeviceOverviewWorker
from app.gui.workers.pre_checklist_worker import PreChecklistWorker
from app.gui.workers.pre_work_worker import PreWorkWorker
from app.modules.os_upgrade.device_overview import DeviceOverviewReport
from app.modules.os_upgrade.overview_paths import new_job_workspace, report_path
from app.modules.os_upgrade.overview_report import write_overview_html
from app.modules.os_upgrade.pre_checklist import PreChecklistReport
from app.modules.os_upgrade.pre_checklist_report import write_pre_checklist_html
from app.modules.os_upgrade.pre_work import PreWorkReport
from app.modules.os_upgrade.pre_work_report import write_pre_work_html

_BTN_MIN_H = 34


@dataclass(frozen=True)
class WorkStepDef:
    key: str
    number: str
    title: str
    report_window_title: str


WORK_STEPS: tuple[WorkStepDef, ...] = (
    WorkStepDef("device_overview", "1", "장비 개요", "장비 개요 Report"),
    WorkStepDef("pre_checklist", "2", "작업 전 Check List", "작업 전 Check List Report"),
    WorkStepDef("pre_work", "3", "사전 작업", "사전 작업 Report"),
    WorkStepDef("post_checklist", "4", "작업 후 Check List", "작업 후 Check List Report"),
)


class OsUpgradeCheckView(QWidget):
    """OS 업그레이드 간 점검 — 장비 연결 + 작업 단계 버튼."""

    def __init__(self, project_root: Path, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.project_root = project_root
        self.output_root = module_output_root(project_root, "os_upgrade")
        self.data_dir = local_data_dir()
        self._workspace: Path | None = None
        self._folder_name: str | None = None
        self._overview_worker: DeviceOverviewWorker | None = None
        self._pre_checklist_worker: PreChecklistWorker | None = None
        self._pre_work_worker: PreWorkWorker | None = None
        self._post_checklist_worker: PreChecklistWorker | None = None
        self._last_pre_work_reports: list[PreWorkReport] = []
        self._last_post_reports: list[PreChecklistReport] = []
        self._reports: dict[str, Path] = {}
        self._run_buttons: dict[str, QPushButton] = {}
        self._report_buttons: dict[str, QPushButton] = {}
        self._last_overview_reports: list[DeviceOverviewReport] = []
        self._last_pre_reports: list[PreChecklistReport] = []
        self._build_ui()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        root = QVBoxLayout(content)
        root.setSpacing(12)

        title = QLabel("OS 업그레이드 간 점검")
        mark_page_title(title)
        root.addWidget(title)

        subtitle = QLabel(
            "Test Connection 후 작업 라벨을 입력하고 단계별 「실행」을 누르세요. "
            "HTML 리포트가 생성되면 같은 열의 「Report」가 나타납니다."
        )
        subtitle.setWordWrap(True)
        mark_page_subtitle(subtitle)
        root.addWidget(subtitle)

        self.connection = DeviceConnectionPanel(self.data_dir)
        self.connection.connection_test_finished.connect(self._on_connection_test_finished)
        root.addWidget(self.connection)

        work_box = QGroupBox("작업 (Test Connection 이후)")
        work_layout = QVBoxLayout(work_box)
        work_layout.setSpacing(10)

        meta_form = QFormLayout()
        self.work_label_edit = QLineEdit()
        self.work_label_edit.setPlaceholderText("예: 고객사명, 사이트 — output/os_upgrade/날짜_라벨/ 폴더명")
        meta_form.addRow("작업 라벨", self.work_label_edit)
        self.target_version_combo = QComboBox()
        configure_form_combobox(self.target_version_combo)
        for ent in load_k7727_versions():
            self.target_version_combo.addItem(ent.label, ent.version)
        if self.target_version_combo.count():
            self.target_version_combo.setCurrentIndex(0)
        meta_form.addRow("목표 버전", self.target_version_combo)
        ver_hint = QLabel(
            "Check List: 작업 전만 License/Service Check Date 비교 · 작업 후는 생략"
        )
        ver_hint.setWordWrap(True)
        ver_hint.setProperty("role", "muted")
        work_layout.addLayout(meta_form)
        work_layout.addWidget(ver_hint)

        self.pre_work_ucs_backup_cb = NcurityCheckBox("사전 작업 시 UCS 백업 수행")
        self.pre_work_ucs_backup_cb.setChecked(True)
        self.pre_work_ucs_backup_cb.setToolTip(
            "체크 해제 시 Session·Linux·f5mku는 실행하고 UCS(stagger)만 생략합니다."
        )
        work_layout.addWidget(self.pre_work_ucs_backup_cb)

        steps_hint = QLabel("단계별 실행 · Report (실행 전에는 비활성)")
        steps_hint.setProperty("role", "muted")
        work_layout.addWidget(steps_hint)

        steps_row = QHBoxLayout()
        steps_row.setSpacing(10)
        for step in WORK_STEPS:
            card = QFrame()
            mark_step_card(card)
            col = QVBoxLayout(card)
            col.setContentsMargins(12, 12, 12, 12)
            col.setSpacing(8)

            title_lbl = QLabel(f"{step.number}. {step.title}")
            title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            title_lbl.setProperty("role", "stepTitle")
            col.addWidget(title_lbl)

            run_btn = QPushButton("실행")
            run_btn.setMinimumHeight(_BTN_MIN_H)
            mark_primary_button(run_btn)
            run_btn.setSizePolicy(
                QSizePolicy.Policy.Expanding,
                QSizePolicy.Policy.Fixed,
            )
            run_btn.setEnabled(False)
            col.addWidget(run_btn)
            self._run_buttons[step.key] = run_btn

            report_btn = QPushButton("Report")
            report_btn.setMinimumHeight(_BTN_MIN_H)
            mark_secondary_button(report_btn)
            report_btn.setSizePolicy(
                QSizePolicy.Policy.Expanding,
                QSizePolicy.Policy.Fixed,
            )
            report_btn.setEnabled(False)
            report_btn.setToolTip("해당 단계 「실행」 후 활성화됩니다.")
            col.addWidget(report_btn)
            self._report_buttons[step.key] = report_btn

            steps_row.addWidget(card, stretch=1)

        work_layout.addLayout(steps_row)

        self.overview_progress = QProgressBar()
        self.overview_progress.setVisible(False)
        self.overview_progress.setFormat("%p% — %v")
        work_layout.addWidget(self.overview_progress)

        self.progress_label = QLabel("")
        self.progress_label.setWordWrap(True)
        self.progress_label.setProperty("role", "muted")
        work_layout.addWidget(self.progress_label)

        self.summary_edit = QTextEdit()
        self.summary_edit.setReadOnly(True)
        self.summary_edit.setPlaceholderText("단계 「실행」 후 요약(✓/✗)이 표시됩니다.")
        self.summary_edit.setMinimumHeight(120)
        self.summary_edit.setMaximumHeight(200)
        work_layout.addWidget(self.summary_edit)

        footer_row = QHBoxLayout()
        self.open_folder_btn = QPushButton("작업 폴더 열기")
        self.open_folder_btn.setMinimumHeight(_BTN_MIN_H)
        footer_row.addWidget(self.open_folder_btn)
        footer_row.addStretch()
        work_layout.addLayout(footer_row)

        self.report_path_label = QLabel("저장 위치: (작업 실행 후 표시)")
        self.report_path_label.setWordWrap(True)
        self.report_path_label.setProperty("role", "muted")
        work_layout.addWidget(self.report_path_label)

        root.addWidget(work_box)

        self._run_buttons["device_overview"].clicked.connect(self._run_device_overview)
        self._run_buttons["pre_checklist"].clicked.connect(self._run_pre_checklist)
        self._run_buttons["pre_work"].clicked.connect(self._run_pre_work)
        self._run_buttons["post_checklist"].clicked.connect(self._run_post_checklist)
        for step in WORK_STEPS:
            self._report_buttons[step.key].clicked.connect(
                lambda _checked=False, k=step.key: self._open_report(k)
            )
        self.open_folder_btn.clicked.connect(self._open_output_folder)

        root.addStretch()

    def _step_def(self, key: str) -> WorkStepDef:
        for step in WORK_STEPS:
            if step.key == key:
                return step
        raise KeyError(key)

    def _reset_reports_ui(self) -> None:
        self._reports.clear()
        for btn in self._report_buttons.values():
            btn.setEnabled(False)

    def _mark_report_ready(self, key: str, html_path: Path) -> None:
        self._reports[key] = html_path
        self._report_buttons[key].setEnabled(True)

    def _work_label(self) -> str:
        return self.work_label_edit.text().strip() or "work"

    def _target_version_key(self) -> str:
        return str(self.target_version_combo.currentData() or "")

    def _ensure_workspace(self) -> Path:
        if self._workspace is None:
            label = self._work_label()
            if not self.work_label_edit.text().strip():
                QMessageBox.information(
                    self,
                    "작업 라벨",
                    "작업 라벨이 비어 있어 기본값 'work'로 폴더를 만듭니다.",
                )
            self._workspace, self._folder_name = new_job_workspace(
                self.output_root, label
            )
            self.report_path_label.setText(
                f"저장 위치: output/os_upgrade/{self._folder_name}/"
            )
        return self._workspace

    def _open_output_folder(self) -> None:
        if self._workspace and self._workspace.is_dir():
            open_in_file_manager(self._workspace)
            return
        open_in_file_manager(self.output_root)

    def _on_connection_test_finished(self, ok: bool) -> None:
        self._workspace = None
        self._folder_name = None
        self._reset_reports_ui()
        for btn in self._run_buttons.values():
            btn.setEnabled(True)
        hint = "연결 테스트 완료" if ok else "연결 테스트 완료 (일부 실패)"
        self.report_path_label.setText("저장 위치: (첫 「실행」 시 폴더 생성)")
        self.summary_edit.setPlainText(
            f"{hint}\n"
            "작업 라벨 입력 후 각 단계 「실행」 — Report는 HTML 생성 후 활성화됩니다."
        )

    def _placeholder_action(self, name: str, key: str) -> None:
        QMessageBox.information(
            self,
            name,
            f"「{name}」은 다음 구현 예정입니다.\n"
            f"완료 시 Report 버튼이 활성화됩니다.",
        )

    def _set_run_buttons_enabled(self, enabled: bool) -> None:
        for btn in self._run_buttons.values():
            btn.setEnabled(enabled)

    def _begin_work_ui(self, progress_text: str) -> None:
        self._set_run_buttons_enabled(False)
        self.overview_progress.setVisible(True)
        self.overview_progress.setRange(0, 100)
        self.overview_progress.setValue(0)
        self.progress_label.setText(progress_text)

    def _end_work_ui(self) -> None:
        self._set_run_buttons_enabled(True)
        self.overview_progress.setVisible(False)
        self.progress_label.setText("")

    def _run_device_overview(self) -> None:
        if self._overview_worker and self._overview_worker.isRunning():
            return
        try:
            targets, connections = self.connection.collect_targets_and_connections()
        except ValueError as exc:
            QMessageBox.warning(self, "장비 개요", str(exc))
            return
        if not targets:
            QMessageBox.warning(self, "장비 개요", "대상 장비가 없습니다.")
            return

        self._begin_work_ui("장비 개요 수집 준비…")
        self.summary_edit.setPlainText("수집 중…")

        self._overview_worker = DeviceOverviewWorker(targets, connections)
        self._overview_worker.progress.connect(self._on_work_progress)
        self._overview_worker.finished_ok.connect(self._on_overview_ok)
        self._overview_worker.failed.connect(self._on_overview_fail)
        self._overview_worker.finished.connect(self._end_work_ui)
        self._overview_worker.start()

    def _on_work_progress(self, percent: int, message: str) -> None:
        self.overview_progress.setValue(percent)
        self.progress_label.setText(message)

    def _format_summary(self, reports: list[DeviceOverviewReport]) -> str:
        lines: list[str] = []
        for report in reports:
            line = f"{report.device_label}: {report.summary_line()}"
            if report.errors:
                line += f"\n  오류: {'; '.join(report.errors[:2])}"
            lines.append(line)
        return "\n\n".join(lines)

    def _short_report_path(self, html_path: Path) -> str:
        try:
            return str(html_path.relative_to(self.project_root))
        except ValueError:
            return html_path.name

    def _on_overview_ok(self, reports: object) -> None:
        if not isinstance(reports, list):
            return
        typed = [r for r in reports if isinstance(r, DeviceOverviewReport)]
        self._last_overview_reports = typed

        ws = self._ensure_workspace()
        html_path = report_path(ws, "device_overview")
        write_overview_html(html_path, typed, title="장비 개요")
        self._mark_report_ready("device_overview", html_path)

        rel = self._short_report_path(html_path)
        self.report_path_label.setText(
            f"저장: output/os_upgrade/{self._folder_name}/ · 최근 {rel}"
        )
        self.summary_edit.setPlainText(
            f"[1. 장비 개요] 완료 — {len(typed)}대\n"
            f"이 열 「Report」로 HTML을 엽니다.\n\n"
            f"{self._format_summary(typed)}"
        )

    def _format_pre_summary(self, reports: list[PreChecklistReport]) -> str:
        lines: list[str] = []
        for report in reports:
            line = f"{report.device_label} ({report.target_version}): {report.summary_line()}"
            if report.license_check:
                line += f"\n  License: {report.license_check.verdict}"
            if report.linux_check and report.linux_check.crontab_custom_lines:
                line += f"\n  crontab: {report.linux_check.crontab_summary}"
                for cron_ln in report.linux_check.crontab_custom_lines[:5]:
                    line += f"\n    {cron_ln}"
            if report.errors:
                line += f"\n  오류: {'; '.join(report.errors[:2])}"
            lines.append(line)
        return "\n\n".join(lines)

    def _run_pre_checklist(self) -> None:
        if self._pre_checklist_worker and self._pre_checklist_worker.isRunning():
            return
        version_key = self._target_version_key()
        if not version_key:
            QMessageBox.warning(self, "작업 전 Check List", "목표 버전을 선택하세요.")
            return
        try:
            targets, connections = self.connection.collect_targets_and_connections()
        except ValueError as exc:
            QMessageBox.warning(self, "작업 전 Check List", str(exc))
            return
        if not targets:
            QMessageBox.warning(self, "작업 전 Check List", "대상 장비가 없습니다.")
            return

        self._begin_work_ui("작업 전 Check List 준비…")
        self.summary_edit.setPlainText(f"수집 중… (목표: {version_key})")

        self._pre_checklist_worker = PreChecklistWorker(
            targets, connections, version_key
        )
        self._pre_checklist_worker.progress.connect(self._on_work_progress)
        self._pre_checklist_worker.finished_ok.connect(self._on_pre_checklist_ok)
        self._pre_checklist_worker.failed.connect(self._on_pre_checklist_fail)
        self._pre_checklist_worker.finished.connect(self._end_work_ui)
        self._pre_checklist_worker.start()

    def _on_pre_checklist_ok(self, reports: object) -> None:
        if not isinstance(reports, list):
            return
        typed = [r for r in reports if isinstance(r, PreChecklistReport)]
        self._last_pre_reports = typed

        ws = self._ensure_workspace()
        html_path = report_path(ws, "pre_checklist")
        write_pre_checklist_html(html_path, typed)
        self._mark_report_ready("pre_checklist", html_path)

        rel = self._short_report_path(html_path)
        self.report_path_label.setText(
            f"저장: output/os_upgrade/{self._folder_name}/ · 최근 {rel}"
        )
        self.summary_edit.setPlainText(
            f"[2. 작업 전 Check List] 완료 — {len(typed)}대\n"
            f"저장: pre_checklist/\n\n"
            f"{self._format_pre_summary(typed)}"
        )

    def _on_pre_checklist_fail(self, message: str) -> None:
        self.summary_edit.setPlainText(f"실패: {message[:400]}")
        QMessageBox.warning(self, "작업 전 Check List", message[:500])

    def _format_pre_work_summary(self, reports: list[PreWorkReport]) -> str:
        lines: list[str] = []
        for report in reports:
            line = f"{report.device_label}: {report.summary_line()}"
            if report.errors:
                line += f"\n  오류: {'; '.join(report.errors[:2])}"
            lines.append(line)
        return "\n\n".join(lines)

    def _run_pre_work(self) -> None:
        if self._pre_work_worker and self._pre_work_worker.isRunning():
            return
        try:
            targets, connections = self.connection.collect_targets_and_connections()
        except ValueError as exc:
            QMessageBox.warning(self, "사전 작업", str(exc))
            return
        if not targets:
            QMessageBox.warning(self, "사전 작업", "대상 장비가 없습니다.")
            return

        ws = self._ensure_workspace()
        run_ucs = self.pre_work_ucs_backup_cb.isChecked()
        self._begin_work_ui("사전 작업 준비…")
        if run_ucs:
            status = "수집·백업 중… (UCS는 마지막에 stagger)"
        else:
            status = "수집·백업 중… (UCS 백업 생략)"
        self.summary_edit.setPlainText(status)

        self._pre_work_worker = PreWorkWorker(
            targets, connections, ws, run_ucs_backup=run_ucs
        )
        self._pre_work_worker.progress.connect(self._on_work_progress)
        self._pre_work_worker.finished_ok.connect(self._on_pre_work_ok)
        self._pre_work_worker.failed.connect(self._on_pre_work_fail)
        self._pre_work_worker.finished.connect(self._end_work_ui)
        self._pre_work_worker.start()

    def _on_pre_work_ok(self, reports: object) -> None:
        if not isinstance(reports, list):
            return
        typed = [r for r in reports if isinstance(r, PreWorkReport)]
        self._last_pre_work_reports = typed

        ws = self._ensure_workspace()
        html_path = report_path(ws, "pre_work")
        write_pre_work_html(html_path, typed)
        self._mark_report_ready("pre_work", html_path)

        rel = self._short_report_path(html_path)
        self.report_path_label.setText(
            f"저장: output/os_upgrade/{self._folder_name}/ · 최근 {rel}"
        )
        ucs_note = (
            "UCS: ucs_backup.log"
            if any(r.ucs_log_rel for r in typed)
            else "UCS: 생략 (미선택)"
        )
        self.summary_edit.setPlainText(
            f"[3. 사전 작업] 완료 — {len(typed)}대\n"
            f"백업: backups/&lt;장비&gt;/ · {ucs_note}\n\n"
            f"{self._format_pre_work_summary(typed)}"
        )

    def _on_pre_work_fail(self, message: str) -> None:
        self.summary_edit.setPlainText(f"실패: {message[:400]}")
        QMessageBox.warning(self, "사전 작업", message[:500])

    def _run_post_checklist(self) -> None:
        if self._post_checklist_worker and self._post_checklist_worker.isRunning():
            return
        version_key = self._target_version_key()
        if not version_key:
            QMessageBox.warning(self, "작업 후 Check List", "목표 버전을 선택하세요.")
            return
        try:
            targets, connections = self.connection.collect_targets_and_connections()
        except ValueError as exc:
            QMessageBox.warning(self, "작업 후 Check List", str(exc))
            return
        if not targets:
            QMessageBox.warning(self, "작업 후 Check List", "대상 장비가 없습니다.")
            return

        self._begin_work_ui("작업 후 Check List 준비…")
        self.summary_edit.setPlainText(f"수집 중… (목표: {version_key})")

        self._post_checklist_worker = PreChecklistWorker(
            targets,
            connections,
            version_key,
            phase="post",
        )
        self._post_checklist_worker.progress.connect(self._on_work_progress)
        self._post_checklist_worker.finished_ok.connect(self._on_post_checklist_ok)
        self._post_checklist_worker.failed.connect(self._on_post_checklist_fail)
        self._post_checklist_worker.finished.connect(self._end_work_ui)
        self._post_checklist_worker.start()

    def _on_post_checklist_ok(self, reports: object) -> None:
        if not isinstance(reports, list):
            return
        typed = [r for r in reports if isinstance(r, PreChecklistReport)]
        self._last_post_reports = typed

        ws = self._ensure_workspace()
        html_path = report_path(ws, "post_checklist")
        write_pre_checklist_html(
            html_path,
            typed,
            title="작업 후 Check List",
            include_license_check=False,
        )
        self._mark_report_ready("post_checklist", html_path)

        rel = self._short_report_path(html_path)
        self.report_path_label.setText(
            f"저장: output/os_upgrade/{self._folder_name}/ · 최근 {rel}"
        )
        self.summary_edit.setPlainText(
            f"[4. 작업 후 Check List] 완료 — {len(typed)}대\n"
            f"저장: post_checklist/\n\n"
            f"{self._format_pre_summary(typed)}"
        )

    def _on_post_checklist_fail(self, message: str) -> None:
        self.summary_edit.setPlainText(f"실패: {message[:400]}")
        QMessageBox.warning(self, "작업 후 Check List", message[:500])

    def _on_overview_fail(self, message: str) -> None:
        self.summary_edit.setPlainText(f"실패: {message[:400]}")
        QMessageBox.warning(self, "장비 개요", message[:500])

    def _open_report(self, key: str) -> None:
        step = self._step_def(key)
        path = self._reports.get(key)
        if path and path.is_file():
            dlg = ReportWindow(path, self)
            dlg.setWindowTitle(step.report_window_title)
            dlg.exec()
        else:
            QMessageBox.information(
                self,
                "Report",
                f"먼저 「{step.number}. {step.title}」을 실행하세요.",
            )

    def closeEvent(self, event) -> None:  # noqa: N802
        for worker in (
            self._overview_worker,
            self._pre_checklist_worker,
            self._pre_work_worker,
            self._post_checklist_worker,
        ):
            if worker and worker.isRunning():
                worker.wait(8000)
        super().closeEvent(event)
