from __future__ import annotations

from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape

from app.core.models import ReportContext
from app.modules.health_check.common_eval import evaluate_common
from app.modules.health_check.f5os_detect import (
    f5os_collection_attempted,
    is_rseries_device,
)
from app.modules.health_check.module_report import (
    build_module_summary_by_device,
    module_section_title,
)

_TEMPLATE_DIR = Path(__file__).resolve().parents[2] / "templates"


def render_html_report(context: ReportContext, output_path: Path) -> None:
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATE_DIR)),
        autoescape=select_autoescape(["html", "xml"]),
    )
    template = env.get_template("health_check_report.html.j2")
    checklist_by_device: dict[str, list] = {}
    for device in context.devices:
        data = device.data if isinstance(device.data, dict) else {}
        common = data.get("common") if isinstance(data.get("common"), dict) else {}
        checklist_by_device[device.device_label] = evaluate_common(
            tmos=common.get("tmos") if isinstance(common.get("tmos"), dict) else None,
            f5os=common.get("f5os") if isinstance(common.get("f5os"), dict) else None,
            is_rseries=is_rseries_device(data),
            f5os_attempted=f5os_collection_attempted(data),
        )
    html = template.render(
        job_id=context.job_id,
        site_name=context.site_name,
        period=context.period,
        engineer_notes=context.engineer_notes,
        devices=context.devices,
        exceptions=context.exceptions,
        checklist_by_device=checklist_by_device,
        module_summary_by_device=build_module_summary_by_device(context.devices),
        module_section_title=module_section_title,
    )
    output_path.write_text(html, encoding="utf-8")
