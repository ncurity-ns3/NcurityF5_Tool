import pytest
from pydantic import SecretStr

from app.core.bigip_client import BigipClient
from app.core.models import ConnectionProfile, DeviceTarget
from app.core.safety_gate import ChangeModeDisabledError, SafetyGate


def test_post_blocked() -> None:
    profile = ConnectionProfile(
        target=DeviceTarget(label="lab", host="203.0.113.10"),
        username="admin",
        password=SecretStr("x"),
    )
    client = BigipClient(profile, safety_gate=SafetyGate(False))
    with pytest.raises(ChangeModeDisabledError):
        client.post("/tm/ltm/pool", {"name": "t"})
