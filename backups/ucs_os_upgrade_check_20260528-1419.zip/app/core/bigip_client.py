from __future__ import annotations

from typing import Any

import httpx

from app.core.models import ConnectionProfile, OperationClass
from app.core.redaction import redact_data
from app.core.safety_gate import SafetyGate


def _httpx_read_timeout(read_seconds: float) -> httpx.Timeout:
    """Explicit read cap — avoids util/bash POST hanging with no TMOS activity."""
    return httpx.Timeout(connect=30.0, read=read_seconds, write=30.0, pool=30.0)


class BigipClient:
    """read-only icontrol rest client (subset) with safety gate on writes."""

    def __init__(
        self,
        profile: ConnectionProfile,
        *,
        safety_gate: SafetyGate | None = None,
        timeout: float = 120.0,
    ) -> None:
        self.profile = profile
        self.safety_gate = safety_gate or SafetyGate()
        self.timeout = timeout
        self._token: str | None = None
        self._use_basic_auth = False
        self._basic_probe_body: dict[str, Any] = {}

    def _base_url(self) -> str:
        target = self.profile.target
        return f"https://{target.host}:{target.port}/mgmt"

    def _auth_headers(self) -> dict[str, str]:
        if self._token and not self._use_basic_auth:
            return {"x-f5-auth-token": self._token}
        return {}

    def _http_auth(self) -> tuple[str, str] | None:
        if self._use_basic_auth:
            return (
                self.profile.username,
                self.profile.password.get_secret_value(),
            )
        return None

    def _probe_basic_auth(self) -> bool:
        """some tenants allow read-only GET with basic auth when token login returns 401."""
        url = f"{self._base_url()}/tm/sys/version"
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
            response = client.get(
                url,
                auth=(self.profile.username, self.profile.password.get_secret_value()),
            )
            if response.status_code == 200:
                self._use_basic_auth = True
                self._token = "basic-auth"
                self._basic_probe_body = redact_data(response.json())
                return True
        return False

    def authenticate(self) -> None:
        self._use_basic_auth = False
        self._basic_probe_body = {}
        url = f"{self._base_url()}/shared/authn/login"
        password = self.profile.password.get_secret_value()
        payloads = [
            {
                "username": self.profile.username,
                "password": password,
                "loginProviderName": "tmos",
            },
            {"username": self.profile.username, "password": password},
            {
                "username": self.profile.username,
                "password": password,
                "loginProviderName": "local",
            },
        ]
        headers = {"Content-Type": "application/json"}
        last_error: httpx.HTTPStatusError | None = None
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
            for payload in payloads:
                response = client.post(url, json=payload, headers=headers)
                if response.status_code == 401:
                    last_error = response
                    continue
                response.raise_for_status()
                body = response.json()
                self._token = body.get("token", {}).get("token")
                if self._token:
                    return
        if self._probe_basic_auth():
            return
        if last_error is not None:
            last_error.raise_for_status()
        raise RuntimeError("TMOS: login failed (no token, basic auth probe failed)")

    def get(self, path: str) -> dict[str, Any]:
        if not self._token:
            self.authenticate()
        if not path.startswith("/"):
            path = f"/{path}"
        url = f"{self._base_url()}{path}"
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
            response = client.get(
                url,
                headers=self._auth_headers(),
                auth=self._http_auth(),
            )
            response.raise_for_status()
            return redact_data(response.json())

    def auth_mode_label(self) -> str:
        return "basic auth" if self._use_basic_auth else "token"

    def connection_summary(self) -> str:
        """short label after successful authenticate (for gui)."""
        if self._use_basic_auth:
            entry = self._basic_probe_body.get("entry", self._basic_probe_body)
            if isinstance(entry, str):
                return entry[:80]
            if isinstance(entry, list) and entry:
                return str(entry[0])[:80]
            return "basic auth OK"
        info = self.get_system_info()
        return str(
            info.get("hostname") or info.get("version") or info.get("marketingName", "OK")
        )[:80]

    def post(
        self, path: str, payload: dict[str, Any], *, timeout: float | None = None
    ) -> dict[str, Any]:
        self.safety_gate.assert_allowed(OperationClass.wr)
        if not path.startswith("/"):
            path = f"/{path}"
        url = f"{self._base_url()}{path}"
        read_s = float(timeout if timeout is not None else self.timeout)
        req_timeout = _httpx_read_timeout(read_s)
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=req_timeout) as client:
            response = client.post(
                url,
                json=payload,
                headers={**self._auth_headers(), "Content-Type": "application/json"},
                auth=self._http_auth(),
            )
            response.raise_for_status()
            return redact_data(response.json())

    def save_sys_ucs(self, filename: str, *, timeout: float = 180.0) -> dict[str, Any]:
        """POST /tm/sys/ucs — command save (device may finish after HTTP returns)."""
        name = filename.rsplit("/", 1)[-1]
        return self.post(
            "/tm/sys/ucs",
            {"command": "save", "name": name},
            timeout=timeout,
        )

    def get_system_info(self) -> dict[str, Any]:
        return self.get("/tm/sys/global-settings")

    def get_failover_state(self) -> dict[str, Any]:
        try:
            return self.get("/tm/cm/failover-status")
        except httpx.HTTPError:
            return {"status": "unknown"}

    def get_vlan_summary(self) -> dict[str, Any]:
        return self.get("/tm/net/vlan")

    def get_self_ip_summary(self) -> dict[str, Any]:
        return self.get("/tm/net/self")

    def get_route_summary(self) -> dict[str, Any]:
        return self.get("/tm/net/route")

    def get_pool_summary(self) -> dict[str, Any]:
        return self.get("/tm/ltm/pool")

    def get_optional(self, path: str) -> dict[str, Any]:
        """Best-effort GET; returns empty dict or {_unavailable: true} on HTTP errors."""
        if not self._token:
            self.authenticate()
        if not path.startswith("/"):
            path = f"/{path}"
        url = f"{self._base_url()}{path}"
        try:
            with httpx.Client(verify=self.profile.target.verify_tls, timeout=self.timeout) as client:
                response = client.get(
                    url,
                    headers=self._auth_headers(),
                    auth=self._http_auth(),
                )
                if response.status_code in (400, 401, 403, 404, 405):
                    return {
                        "_unavailable": True,
                        "_path": path,
                        "_error": f"HTTP {response.status_code}",
                        "_http_status": response.status_code,
                    }
                response.raise_for_status()
                if not response.content:
                    return {}
                return redact_data(response.json())
        except httpx.HTTPError as exc:
            return {"_unavailable": True, "_path": path, "_error": str(exc)[:200]}

    def collect_common_tmos_rest(self) -> dict[str, Any]:
        """REST equivalents for 정기점검 Common TMOS checks."""
        paths = {
            "uptime": "/tm/sys/uptime",
            "hardware": "/tm/sys/hardware",
            "interfaces": "/tm/net/interface",
            "ntp": "/tm/sys/ntp",
            "clock": "/tm/sys/clock",
            "disk": "/tm/sys/disk",
            "filesystem": "/tm/sys/filesystem",
            "services": "/tm/sys/service",
            "performance": "/tm/sys/performance",
            "certs": "/tm/sys/crypto/cert",
            "ucs": "/tm/sys/ucs",
        }
        return {key: self.get_optional(path) for key, path in paths.items()}

    def run_util_bash(self, shell_command: str, *, timeout: float | None = None) -> str:
        """
        Run read-only (or explicit backup) shell via iControl POST /tm/util/bash.
        Does not use SafetyGate — caller must not pass destructive commands except UCS save.
        """
        if not self._token:
            self.authenticate()
        escaped = shell_command.replace("'", "'\"'\"'")
        payload = {"command": "run", "utilCmdArgs": f"-c '{escaped}'"}
        url = f"{self._base_url()}/tm/util/bash"
        read_s = float(timeout if timeout is not None else self.timeout)
        req_timeout = _httpx_read_timeout(read_s)
        with httpx.Client(verify=self.profile.target.verify_tls, timeout=req_timeout) as client:
            response = client.post(
                url,
                json=payload,
                headers={**self._auth_headers(), "Content-Type": "application/json"},
                auth=self._http_auth(),
            )
            response.raise_for_status()
            body = redact_data(response.json())
        result = body.get("commandResult", "")
        if isinstance(result, str):
            text = result.strip()
            if text.lower().startswith("error") or "0107" in text[:20]:
                raise RuntimeError(f"bash rejected: {text[:200]}")
            return text
        return str(result).strip()
