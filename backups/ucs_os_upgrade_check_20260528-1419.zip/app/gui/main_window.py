from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QStackedWidget,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)

from app.gui.branding import (
    APP_TITLE,
    NAV_HEADER_LOGO_MAX_HEIGHT,
    ORG_NAME,
    apply_window_icon,
    load_home_logo_pixmap,
)
from app.gui.form_controls import apply_form_control_policies
from app.gui.theme import polish_widget_scrollbars
from app.gui.session_manager import SessionManager
from app.gui.widgets.device_connection_panel import DeviceConnectionPanel
from app.gui.views.health_check_view import HealthCheckView
from app.gui.views.home_view import HomeView
from app.gui.views.os_upgrade_check_view import OsUpgradeCheckView
from app.gui.views.placeholder_view import PlaceholderView


class MainWindow(QMainWindow):
    def __init__(self, project_root: Path) -> None:
        super().__init__()

        self.project_root = project_root
        self.setWindowTitle(APP_TITLE)
        apply_window_icon(self)
        self.resize(1140, 800)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        nav_frame = QFrame()
        nav_frame.setObjectName("navFrame")
        nav_frame.setFixedWidth(208)
        nav_layout = QVBoxLayout(nav_frame)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(0)

        nav_header = QFrame()
        nav_header.setObjectName("navHeader")
        header_layout = QVBoxLayout(nav_header)
        header_layout.setContentsMargins(16, 16, 16, 12)
        logo_lbl = QLabel()
        logo_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = load_home_logo_pixmap(max_height=NAV_HEADER_LOGO_MAX_HEIGHT, on_dark=False)
        if pix is not None:
            logo_lbl.setPixmap(pix)
            logo_lbl.setFixedSize(pix.width(), pix.height())
        header_layout.addWidget(logo_lbl, alignment=Qt.AlignmentFlag.AlignCenter)
        nav_layout.addWidget(nav_header)

        self.nav = QListWidget()
        self.nav.setObjectName("navList")
        for name in [
            "Home",
            "Initial Setup",
            "정기 점검",
            "OS 업그레이드 간 점검",
            "VPE Macro",
            "Reports",
            "Devices",
            "Settings",
        ]:
            QListWidgetItem(name, self.nav)
        self.nav.setCurrentRow(0)
        nav_layout.addWidget(self.nav, stretch=1)

        layout.addWidget(nav_frame)

        content_host = QWidget()
        content_host.setObjectName("contentHost")
        content_layout = QVBoxLayout(content_host)
        content_layout.setContentsMargins(24, 20, 24, 20)
        content_layout.setSpacing(0)

        self.stack = QStackedWidget()
        self.stack.addWidget(HomeView())
        self.stack.addWidget(
            PlaceholderView(
                "Initial Setup",
                "초기 설정 설계 화면 — hostname, mgmt, vlan 등 (다음 구현)",
            )
        )
        self.stack.addWidget(HealthCheckView(project_root))
        self.stack.addWidget(OsUpgradeCheckView(project_root))
        self.stack.addWidget(
            PlaceholderView("VPE Macro", "APM VPE macro 설계 wizard (다음 구현)")
        )
        self.stack.addWidget(
            PlaceholderView("Reports", "과거 job 리포트 브라우저 (다음 구현)")
        )
        self.stack.addWidget(
            PlaceholderView("Devices", "저장된 device profile (username만, pw 없음)")
        )
        self.stack.addWidget(
            PlaceholderView("Settings", "출력 폴더, 세션 옵션 (다음 구현)")
        )
        content_layout.addWidget(self.stack)
        layout.addWidget(content_host, stretch=1)

        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        apply_form_control_policies(self)
        polish_widget_scrollbars(self)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage(f"{APP_TITLE}  ·  offline  ·  {ORG_NAME}")

        self.menuBar().hide()

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        polish_widget_scrollbars(self)

    def closeEvent(self, event) -> None:  # noqa: N802
        for panel in self.findChildren(DeviceConnectionPanel):
            panel._stop_test_worker()
        SessionManager.instance().clear_all()
        super().closeEvent(event)
