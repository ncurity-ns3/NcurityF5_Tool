from app.modules.vpe_macro.generator import generate_vpe_macro_artifacts

__all__ = ["generate_vpe_macro_artifacts"]
