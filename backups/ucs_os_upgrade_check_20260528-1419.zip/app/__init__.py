"""f5 field automation platform."""

__version__ = "0.1.0"
