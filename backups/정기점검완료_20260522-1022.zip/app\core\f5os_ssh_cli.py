from __future__ import annotations

import re
import time
try:
    import paramiko
except ImportError:  # pragma: no cover - optional until pip install
    paramiko = None  # type: ignore[assignment,misc]

_PASSWORD_PROMPT = re.compile(r"assword\s*:\s*$", re.M | re.I)
_BASH_PROMPT = re.compile(r"[\]#\$]\s*$|[\]#]\s|bash-\d", re.M | re.I)


def _read_channel(chan: "paramiko.Channel", timeout: float = 30.0) -> str:
    deadline = time.monotonic() + timeout
    chunks: list[str] = []
    while time.monotonic() < deadline:
        if chan.recv_ready():
            data = chan.recv(65535)
            if not data:
                break
            chunks.append(data.decode("utf-8", errors="replace"))
            deadline = time.monotonic() + 2.0
        elif chan.exit_status_ready():
            break
        else:
            time.sleep(0.15)
    return "".join(chunks)


def _send(chan: "paramiko.Channel", text: str) -> None:
    chan.send(text if text.endswith("\n") else text + "\n")


def _strip_ansi(text: str) -> str:
    return re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", text)


def _in_admin_cli(buf: str) -> bool:
    clean = _strip_ansi(buf)
    if _PASSWORD_PROMPT.search(clean[-400:]):
        return False
    if "management cli" in clean.lower() or "welcome to the management" in clean.lower():
        return True
    lines = [ln.strip() for ln in clean.splitlines() if ln.strip()]
    if not lines:
        return False
    last = lines[-1]
    if _BASH_PROMPT.search(last) or "[root@" in last.lower():
        return False
    return bool(re.search(r"[#>]\s*$", last))


def _enter_admin_shell(
    chan: "paramiko.Channel",
    admin_user: str,
    admin_password: str,
    *,
    timeout: float,
) -> bool:
    buf = _read_channel(chan, timeout=min(timeout, 12.0))
    if _in_admin_cli(buf):
        return True
    _send(chan, f"su - {admin_user}")
    buf += _read_channel(chan, timeout=10.0)
    if _PASSWORD_PROMPT.search(_strip_ansi(buf)[-300:]):
        _send(chan, admin_password)
        buf += _read_channel(chan, timeout=10.0)
    return _in_admin_cli(buf)


def _clean_command_output(raw: str, command: str) -> str:
    clean = _strip_ansi(raw)
    lines = clean.splitlines()
    trimmed: list[str] = []
    for line in lines:
        s = line.strip()
        if not s:
            continue
        if s == command or s.endswith(command):
            continue
        if re.match(r"^[\w.-]+[#>]\s*$", s):
            continue
        if s.lower().startswith("password:"):
            continue
        trimmed.append(line)
    return "\n".join(trimmed).strip()


def _run_one_command(chan: "paramiko.Channel", command: str, *, timeout: float) -> str:
    """F5OS CLI command (not bash) — read until admin prompt returns."""
    _send(chan, command)
    deadline = time.monotonic() + timeout
    chunks: list[str] = []
    while time.monotonic() < deadline:
        if chan.recv_ready():
            chunks.append(chan.recv(65535).decode("utf-8", errors="replace"))
            tail = _strip_ansi("".join(chunks))[-600:]
            if len(tail) > 30 and re.search(r"[#>]\s*$", tail.splitlines()[-1] if tail.splitlines() else ""):
                break
        else:
            time.sleep(0.12)
    return _clean_command_output("".join(chunks), command)


def run_f5os_admin_cli(
    host: str,
    admin_password: str,
    commands: list[str],
    *,
    admin_user: str = "admin",
    ssh_port: int = 22,
    timeout: float = 90.0,
    ssh_users: tuple[str, ...] = ("admin", "root"),
) -> dict[str, str]:
    """
    SSH to platform (bash), ``su admin``, run F5OS show commands.
    Returns {command: stdout} for commands that returned non-empty text.
    """
    if paramiko is None:
        return {}
    if not host or not admin_password or not commands:
        return {}

    last_error: Exception | None = None
    for ssh_user in ssh_users:
        if ssh_user != admin_user and ssh_user != "root":
            continue
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            client.connect(
                hostname=host,
                port=ssh_port,
                username=ssh_user,
                password=admin_password,
                timeout=min(timeout, 30.0),
                allow_agent=False,
                look_for_keys=False,
                banner_timeout=20.0,
                auth_timeout=20.0,
            )
            chan = client.invoke_shell(term="vt100", width=220, height=48)
            chan.settimeout(timeout)
            if not _enter_admin_shell(chan, admin_user, admin_password, timeout=timeout):
                client.close()
                continue
            outputs: dict[str, str] = {}
            for cmd in commands:
                text = _run_one_command(chan, cmd, timeout=timeout)
                if text.strip():
                    outputs[cmd] = text
            client.close()
            if outputs:
                return outputs
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            try:
                client.close()
            except Exception:  # noqa: BLE001
                pass
    if last_error:
        return {"_ssh_error": str(last_error)[:200]}
    return {}


def first_ssh_admin_show(
    host: str,
    admin_password: str,
    *commands: str,
    admin_user: str = "admin",
    ssh_port: int = 22,
    timeout: float = 90.0,
) -> str:
    """Run command aliases in one SSH session; first non-empty output wins."""
    if not commands:
        return ""
    ordered: list[str] = []
    for cmd in commands:
        if cmd not in ordered:
            ordered.append(cmd)
    result = run_f5os_admin_cli(
        host,
        admin_password,
        ordered,
        admin_user=admin_user,
        ssh_port=ssh_port,
        timeout=timeout,
    )
    if "_ssh_error" in result and len(result) == 1:
        return ""
    for cmd in ordered:
        text = result.get(cmd, "").strip()
        if text:
            return text
    return ""
