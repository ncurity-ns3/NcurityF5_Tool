from __future__ import annotations

from PyQt6.QtWidgets import QLabel, QVBoxLayout, QWidget


class PlaceholderView(QWidget):
    def __init__(self, title_en: str, desc_ko: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"<h2>{title_en}</h2>"))
        layout.addWidget(QLabel(desc_ko))
        layout.addStretch()
