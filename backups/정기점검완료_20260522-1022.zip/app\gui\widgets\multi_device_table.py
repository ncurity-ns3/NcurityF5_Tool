from __future__ import annotations

from dataclasses import dataclass

from PyQt6.QtCore import QEvent, QObject, Qt, pyqtSignal
from PyQt6.QtGui import QBrush, QColor
from PyQt6.QtWidgets import (
    QComboBox,
    QHeaderView,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QWidget,
)

from app.core.models import PlatformKind
from app.gui.device_models import MODEL_ISERIES, MODEL_RSERIES, normalize_device_model
from app.gui.widgets.multi_device_entry import DeviceRowData

COL_MODEL, COL_LABEL, COL_STACK, COL_MGMT, COL_USER, COL_PASS = range(6)
_STACK_F5OS = "F5OS"
_STACK_TMOS = "TMOS"


@dataclass
class _DeviceBlock:
    start_row: int
    row_count: int


class _FocusSelectRowFilter(QObject):
    """Highlight the device block when a cell widget receives focus (no focus steal)."""

    def __init__(self, panel: "MultiDeviceTablePanel") -> None:
        super().__init__(panel)
        self._panel = panel

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:  # noqa: N802
        if (
            event.type() == QEvent.Type.FocusIn
            and not self._panel._suppress_focus_select
        ):
            row = obj.property("_table_row")
            if row is not None:
                idx = self._panel._block_index_for_row(int(row))
                if idx >= 0:
                    self._panel._highlight_block(idx)
        return False


class MultiDeviceTablePanel(QWidget):
    """two-row-per-device table: Model/Label span rows; Stack = F5OS then TMOS for rSeries."""

    devices_structure_changed = pyqtSignal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        from PyQt6.QtWidgets import QVBoxLayout

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.table = QTableWidget(0, 6)
        self._apply_headers(per_device=False)
        self.table.setMinimumHeight(200)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setStyleSheet(
            "QTableWidget::item:selected {"
            "  background-color: #2563eb; color: #ffffff;"
            "}"
            "QTableWidget::item:focus {"
            "  border: 2px solid #1d4ed8;"
            "}"
        )
        self.table.itemSelectionChanged.connect(self._on_table_selection_changed)
        self.table.currentCellChanged.connect(self._on_table_cell_changed)
        layout.addWidget(self.table)
        self._blocks: list[_DeviceBlock] = []
        self._per_device_auth = False
        self._row_focus_filter = _FocusSelectRowFilter(self)
        self._selected_block_idx = -1
        self._suppress_focus_select = False

    def _apply_headers(self, *, per_device: bool) -> None:
        headers = ["Model", "Label", "Stack", "MGMT IP", "Port"]
        if per_device:
            headers.extend(["User", "Password"])
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)

    def set_per_device_auth(self, enabled: bool) -> None:
        if self._per_device_auth == enabled:
            return
        rows = self.snapshot()
        self._per_device_auth = enabled
        self._apply_headers(per_device=enabled)
        self.rebuild(rows)

    def _text(self, row: int, col: int) -> str:
        widget = self.table.cellWidget(row, col)
        if isinstance(widget, QLineEdit):
            return widget.text().strip()
        item = self.table.item(row, col)
        return item.text().strip() if item else ""

    def _tag_row_widget(self, row: int, widget: QWidget) -> None:
        widget.setProperty("_table_row", row)
        widget.installEventFilter(self._row_focus_filter)

    def _set_password(self, row: int, col: int, password: str) -> None:
        edit = QLineEdit(password)
        edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.table.setCellWidget(row, col, edit)
        self._tag_row_widget(row, edit)

    def _set_text(self, row: int, col: int, text: str, *, editable: bool = True) -> None:
        item = QTableWidgetItem(text)
        if not editable:
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
        self.table.setItem(row, col, item)

    def _mgmt_cols(self) -> tuple[int, int]:
        return COL_MGMT, COL_MGMT + 1

    def _auth_cols(self) -> tuple[int, int]:
        if self._per_device_auth:
            return COL_MGMT + 2, COL_MGMT + 3
        return -1, -1

    def _insert_device(self, data: DeviceRowData) -> None:
        rseries = normalize_device_model(data.model) == MODEL_RSERIES
        row_count = 2 if rseries else 1
        start = self.table.rowCount()
        self.table.insertRow(start)
        if row_count == 2:
            self.table.insertRow(start + 1)

        combo = QComboBox()
        combo.addItems([MODEL_ISERIES, MODEL_RSERIES])
        combo.setCurrentText(normalize_device_model(data.model))
        combo.currentTextChanged.connect(self._on_model_combo_changed)
        self.table.setCellWidget(start, COL_MODEL, combo)
        self._tag_row_widget(start, combo)
        self.table.setItem(start, COL_LABEL, QTableWidgetItem(data.label))

        mgmt_col, port_col = self._mgmt_cols()
        if rseries:
            self._set_stack_row(start, _STACK_F5OS, data.f5os_host, str(data.f5os_port), data.f5os_user, data.f5os_pass)
            self._set_stack_row(
                start + 1,
                _STACK_TMOS,
                data.tmos_host,
                str(data.tmos_port),
                data.tmos_user,
                data.tmos_pass,
            )
        else:
            self._set_stack_row(
                start,
                _STACK_TMOS,
                data.tmos_host,
                str(data.tmos_port),
                data.tmos_user,
                data.tmos_pass,
            )

        if row_count > 1:
            self.table.setSpan(start, COL_MODEL, row_count, 1)
            self.table.setSpan(start, COL_LABEL, row_count, 1)
        self._blocks.append(_DeviceBlock(start_row=start, row_count=row_count))
        self._apply_block_highlight(-1)

    def _block_index_for_row(self, row: int) -> int:
        for i, block in enumerate(self._blocks):
            if block.start_row <= row < block.start_row + block.row_count:
                return i
        return -1

    def _select_block_for_row(self, row: int) -> None:
        """Select table row after rebuild; must not run from FocusIn handlers."""
        idx = self._block_index_for_row(row)
        if idx < 0:
            return
        block = self._blocks[idx]
        self._suppress_focus_select = True
        try:
            self.table.setCurrentCell(block.start_row, COL_LABEL)
            self.table.selectRow(block.start_row)
            self._highlight_block(idx)
        finally:
            self._suppress_focus_select = False

    def _on_table_selection_changed(self) -> None:
        self._highlight_block(self._block_index_for_row(self.table.currentRow()))

    def _on_table_cell_changed(self, row: int, _col: int, _prev_row: int, _prev_col: int) -> None:
        if row >= 0:
            self._highlight_block(self._block_index_for_row(row))

    def _apply_block_highlight(self, active_idx: int) -> None:
        accent = QBrush(QColor("#dbeafe"))
        normal = QBrush()
        for i, block in enumerate(self._blocks):
            brush = accent if i == active_idx else normal
            for r in range(block.start_row, block.start_row + block.row_count):
                for c in range(self.table.columnCount()):
                    item = self.table.item(r, c)
                    if item is not None:
                        item.setBackground(brush)

    def _highlight_block(self, block_idx: int) -> None:
        if block_idx == self._selected_block_idx:
            return
        self._selected_block_idx = block_idx
        self._apply_block_highlight(block_idx)

    def _set_stack_row(
        self,
        row: int,
        stack: str,
        host: str,
        port: str,
        user: str,
        password: str,
    ) -> None:
        self._set_text(row, COL_STACK, stack, editable=False)
        mgmt_col, port_col = self._mgmt_cols()
        self._set_text(row, mgmt_col, host)
        self._set_text(row, port_col, port or "443")
        user_col, pass_col = self._auth_cols()
        if user_col >= 0:
            self._set_text(row, user_col, user or "admin")
            self._set_password(row, pass_col, password)

    def _on_model_combo_changed(self) -> None:
        self.rebuild(self.snapshot())
        self.devices_structure_changed.emit()

    def add_device(self, data: DeviceRowData | None = None) -> None:
        if data is None:
            n = len(self._blocks) + 1
            data = DeviceRowData(
                model=MODEL_ISERIES,
                label=f"device-{n}",
                tmos_port=443,
                f5os_port=443,
            )
        self._insert_device(data)

    def rebuild(self, devices: list[DeviceRowData]) -> None:
        self.table.setRowCount(0)
        self._blocks.clear()
        self._selected_block_idx = -1
        for device in devices:
            self._insert_device(device)
        if self._blocks:
            self._select_block_for_row(self._blocks[0].start_row)

    def snapshot(self) -> list[DeviceRowData]:
        devices: list[DeviceRowData] = []
        mgmt_col, port_col = self._mgmt_cols()
        user_col, pass_col = self._auth_cols()
        for block in self._blocks:
            combo = self.table.cellWidget(block.start_row, COL_MODEL)
            model = MODEL_ISERIES
            if isinstance(combo, QComboBox):
                model = normalize_device_model(combo.currentText())
            label_item = self.table.item(block.start_row, COL_LABEL)
            label = label_item.text().strip() if label_item else "device"
            data = DeviceRowData(model=model, label=label)
            for r in range(block.start_row, block.start_row + block.row_count):
                stack = self._text(r, COL_STACK)
                host = self._text(r, mgmt_col)
                port_s = self._text(r, port_col) or "443"
                try:
                    port = int(port_s)
                except ValueError:
                    port = 443
                user = self._text(r, user_col) if user_col >= 0 else "admin"
                pw = self._text(r, pass_col) if pass_col >= 0 else ""
                if stack == _STACK_F5OS:
                    data.f5os_host = host
                    data.f5os_port = port
                    data.f5os_user = user
                    data.f5os_pass = pw
                elif stack == _STACK_TMOS:
                    data.tmos_host = host
                    data.tmos_port = port
                    data.tmos_user = user
                    data.tmos_pass = pw
            devices.append(data)
        return devices

    def remove_selected_device(self) -> bool:
        row = self.table.currentRow()
        if row < 0:
            return False
        idx = self._block_index_for_row(row)
        if idx < 0:
            return False
        devices = self.snapshot()
        if idx < len(devices):
            devices.pop(idx)
        self.rebuild(devices)
        return True

    def selected_device_index(self) -> int:
        row = self.table.currentRow()
        return self._block_index_for_row(row)

    def any_rseries(self) -> bool:
        return any(
            normalize_device_model(d.model) == MODEL_RSERIES for d in self.snapshot()
        )

    def device_count(self) -> int:
        return len(self._blocks)

    def platform_at(self, index: int) -> PlatformKind:
        devices = self.snapshot()
        if index < 0 or index >= len(devices):
            return PlatformKind.iseries
        if normalize_device_model(devices[index].model) == MODEL_RSERIES:
            return PlatformKind.rseries
        return PlatformKind.iseries
