from __future__ import annotations

from PyQt6.QtWidgets import QLabel, QVBoxLayout, QWidget


class HomeView(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("<h2>Home</h2>"))
        layout.addWidget(
            QLabel(
                "F5 Field Automation — <b>preview build</b><br><br>"
                "왼쪽 메뉴에서 <b>Health Check</b>를 선택하면 "
                "MGMT IP / ID / PW 입력 화면을 볼 수 있습니다.<br><br>"
                "• Single / Multiple<br>"
                "• Fixture Mode로 리포트 미리보기<br>"
                "• Initial Setup / VPE Macro — 다음 단계"
            )
        )
        layout.addStretch()
