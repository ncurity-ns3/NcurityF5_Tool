# f5 field automation

offline windows automation platform for f5 field engineers (phase 1 poc).

## project root

```
C:\Users\ejes3\Ejes_OneDrive\OneDrive - Ncurity\바탕 화면\WorksFiles\F5 Project\Config & Rules & Apps\AI First
```

## gui preview — 화면 보기

```cmd
cd /d "C:\Users\ejes3\Ejes_OneDrive\OneDrive - Ncurity\바탕 화면\WorksFiles\F5 Project\Config & Rules & Apps\AI First"
scripts\setup_dev.cmd
.venv\Scripts\python.exe -m pip install PyQt6 PyQt6-WebEngine
scripts\run_gui.cmd
```

경로에 `&` 가 있으면 (Config & Rules …): `powershell -File scripts\run_gui.ps1`

1. 왼쪽 **Health Check** 클릭  
2. **Fixture Mode** 체크 → **Run Health Check**  
3. 아래 **Report Preview** 에 html 표시  

## quick start (cmd)

```cmd
scripts\setup_dev.cmd
scripts\run_tests.cmd
```

python 설치 문제: [docs/windows_setup.md](docs/windows_setup.md)

## docs

- [docs/spec.md](docs/spec.md) — product spec
- [docs/gui_design.md](docs/gui_design.md) — **gui / ux (mgmt ip, id/pw부터)**
- [docs/ui_flows.md](docs/ui_flows.md) — screen flows
- [docs/gui_field_catalog.md](docs/gui_field_catalog.md) — field ↔ backend mapping
- [docs/roadmap.md](docs/roadmap.md)
- [docs/security_rules.md](docs/security_rules.md)
- [docs/test_plan.md](docs/test_plan.md)
- [docs/windows_setup.md](docs/windows_setup.md)
- [docs/worklog.md](docs/worklog.md)
