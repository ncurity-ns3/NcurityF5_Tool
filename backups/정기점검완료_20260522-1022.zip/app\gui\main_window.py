from __future__ import annotations

from pathlib import Path

from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QStackedWidget,
    QStatusBar,
    QWidget,
)

from app.gui.session_manager import SessionManager
from app.gui.views.health_check_view import HealthCheckView
from app.gui.views.home_view import HomeView
from app.gui.views.placeholder_view import PlaceholderView


class MainWindow(QMainWindow):
    def __init__(self, project_root: Path) -> None:
        super().__init__()
        self.project_root = project_root
        self.setWindowTitle("F5 Field Tool — preview")
        self.resize(1100, 780)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QHBoxLayout(central)

        self.nav = QListWidget()
        self.nav.setFixedWidth(180)
        for name in [
            "Home",
            "Health Check",
            "Initial Setup",
            "VPE Macro",
            "OS Upgrade",
            "Reports",
            "Devices",
            "Settings",
        ]:
            QListWidgetItem(name, self.nav)
        self.nav.setCurrentRow(0)
        layout.addWidget(self.nav)

        self.stack = QStackedWidget()
        self.stack.addWidget(HomeView())
        self.stack.addWidget(HealthCheckView(project_root))
        self.stack.addWidget(
            PlaceholderView(
                "Initial Setup",
                "초기 설정 설계 화면 — hostname, mgmt, vlan 등 (다음 구현)",
            )
        )
        self.stack.addWidget(
            PlaceholderView("VPE Macro", "APM VPE macro 설계 wizard (다음 구현)")
        )
        self.stack.addWidget(
            PlaceholderView("OS Upgrade", "pre/post check — phase 2")
        )
        self.stack.addWidget(
            PlaceholderView("Reports", "과거 job 리포트 브라우저 (다음 구현)")
        )
        self.stack.addWidget(
            PlaceholderView("Devices", "저장된 device profile (username만, pw 없음)")
        )
        self.stack.addWidget(
            PlaceholderView("Settings", "출력 폴더, 세션 옵션 (다음 구현)")
        )
        layout.addWidget(self.stack, stretch=1)

        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("offline | read-only default | preview gui")

        quit_action = QAction("Exit", self)
        quit_action.triggered.connect(self.close)
        self.menuBar().addAction(quit_action)

    def closeEvent(self, event) -> None:  # noqa: N802
        SessionManager.instance().clear_all()
        super().closeEvent(event)
